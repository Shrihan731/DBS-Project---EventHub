"""End-to-end regression for a booking request across organizer/vendor/admin views."""
import pytest
from sqlalchemy import text

from app.database import SessionLocal
from test_role_security import seed_world, call


@pytest.fixture(autouse=True)
def clean_lifecycle_database():
    with SessionLocal() as db:
        for table in (
            "reviews", "bookings", "vendor_offers", "service_requests", "vendor_service",
            "events", "services", "organization_requests", "vendors", "organizations", "users",
        ):
            db.execute(text(f"DELETE FROM {table}"))
        db.commit()
    yield


def test_vendor_booking_request_is_shared_and_cancellation_propagates():
    ids, tokens = seed_world()
    response = call("post", "/requests/", tokens["organizer"], json={
        "event_id": ids["event"], "service_id": ids["service"],
        "vendor_id": ids["vendor"], "budget": 15000,
        "requirements": "Audio support for the event",
    })
    assert response.status_code == 201
    request = response.json()
    assert request["status"] == "pending_vendor_confirmation"

    for role in ("organizer", "vendor", "admin"):
        response = call("get", "/bookings/", tokens[role])
        assert response.status_code == 200
        assert len(response.json()) == 1
        assert response.json()[0]["status"] == "pending_confirmation"

    incoming = call("get", "/requests/incoming", tokens["vendor"])
    assert incoming.status_code == 200
    assert any(item["id"] == request["id"] for item in incoming.json())

    confirmed = call("post", f"/requests/{request['id']}/decision", tokens["vendor"], json={"decision": "accept"})
    assert confirmed.status_code == 200
    assert confirmed.json()["status"] == "booked"
    booking_id = confirmed.json()["id"]
    for role in ("organizer", "vendor", "admin"):
        response = call("get", "/bookings/", tokens[role])
        assert response.json()[0]["status"] == "booked"

    cancelled = call("patch", f"/bookings/{booking_id}", tokens["organizer"], json={"status": "cancelled"})
    assert cancelled.status_code == 200
    for role in ("organizer", "vendor", "admin"):
        response = call("get", "/bookings/", tokens[role])
        assert response.status_code == 200
        assert response.json()[0]["status"] == "cancelled"


def test_cancelled_booking_can_be_rebooked_without_losing_history():
    ids, tokens = seed_world()
    first = call("post", "/requests/", tokens["organizer"], json={
        "event_id": ids["event"], "service_id": ids["service"],
        "vendor_id": ids["vendor"], "budget": 15000,
        "requirements": "First request",
    })
    assert first.status_code == 201, first.text
    first_request_id = first.json()["id"]
    accepted = call("post", f"/requests/{first_request_id}/decision", tokens["vendor"], json={"decision": "accept"})
    assert accepted.status_code == 200, accepted.text
    first_booking_id = accepted.json()["id"]
    cancelled = call("patch", f"/bookings/{first_booking_id}", tokens["organizer"], json={"status": "cancelled"})
    assert cancelled.status_code == 200, cancelled.text

    second = call("post", "/requests/", tokens["organizer"], json={
        "event_id": ids["event"], "service_id": ids["service"],
        "vendor_id": ids["vendor"], "budget": 18000,
        "requirements": "Replacement request after cancellation",
    })
    assert second.status_code == 201, second.text
    assert second.json()["id"] != first_request_id

    with SessionLocal() as db:
        rows = db.execute(text(
            "SELECT id, status, request_id FROM bookings ORDER BY id"
        )).all()
        assert len(rows) == 2
        assert rows[0].status == "cancelled"
        assert rows[1].status == "pending_confirmation"
