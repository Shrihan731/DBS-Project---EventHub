"""Regression tests for role permissions and lifecycle rules.

The test module forces an isolated SQLite database before importing the app so
running pytest never modifies Backend/eventhub.db.
"""
import os
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

_TEST_DB = Path(tempfile.gettempdir()) / f"eventhub_acceptance_{os.getpid()}.db"
os.environ["DATABASE_URL"] = f"sqlite:///{_TEST_DB.as_posix()}"

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Booking, Event, Organization, OrganizationRequest, Review, Service, ServiceRequest, User, Vendor, VendorOffer
from app.security import create_access_token, hash_password

client = TestClient(app)


@pytest.fixture(autouse=True)
def clean_database():
    with SessionLocal() as db:
        for table in (
            "reviews", "bookings", "vendor_offers", "service_requests", "vendor_service",
            "events", "services", "organization_requests", "vendors", "organizations", "users",
        ):
            db.execute(__import__("sqlalchemy").text(f"DELETE FROM {table}"))
        db.commit()
    yield


def seed_world():
    with SessionLocal() as db:
        admin = User(name="Admin Test", email="admin@example.com", role="admin",
                     password_hash=hash_password("AdminPassword123!"), is_active=True)
        organizer = User(name="Organizer Test", email="organizer@example.com", role="organizer",
                         password_hash=hash_password("OrganizerPassword123!"), is_active=True)
        vendor_user = User(name="Vendor Test", email="vendor@example.com", role="vendor",
                           password_hash=hash_password("VendorPassword123!"), is_active=True)
        db.add_all([admin, organizer, vendor_user])
        db.flush()
        organization = Organization(name="Test Organization", organization_type="Club",
                                    contact_email="club@example.com")
        db.add(organization)
        db.flush()
        db.add(OrganizationRequest(
            organizer_id=organizer.id, organization_name=organization.name,
            organization_type=organization.organization_type, contact_email=organization.contact_email,
            organization_id=organization.id, status="approved",
        ))
        vendor = Vendor(vendor_name="Vendor Test", company_name="Vendor Co",
                        contact_number="9876543210", email=vendor_user.email,
                        address="Vellore", user_id=vendor_user.id, approval_status="approved")
        db.add(vendor)
        db.flush()
        service = Service(service_name="Test Audio", category="Audio", description="PA system",
                          vendor_owner_id=vendor.id, is_active=True, is_deleted=False)
        db.add(service)
        db.flush()
        vendor.services.append(service)
        event = Event(event_name="Test Event", event_type="Workshop",
                      event_date=datetime.now() + timedelta(days=7), venue="Auditorium",
                      expected_attendees=100, organizer_id=organizer.id, organization_id=organization.id)
        db.add(event)
        db.commit()
        ids = {"admin": admin.id, "organizer": organizer.id, "vendor_user": vendor_user.id,
               "vendor": vendor.id, "service": service.id, "event": event.id,
               "organization": organization.id}
        tokens = {"admin": create_access_token(admin), "organizer": create_access_token(organizer),
                  "vendor": create_access_token(vendor_user)}
        return ids, tokens


def call(method, path, token=None, **kwargs):
    headers = dict(kwargs.pop("headers", {}))
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return getattr(client, method)(path, headers=headers, **kwargs)


def test_non_admin_cannot_create_organizations_or_users():
    _, tokens = seed_world()
    org_response = call("post", "/organizations/", tokens["organizer"],
                        json={"name": "Unauthorized Organization"})
    user_response = call("post", "/users/", tokens["vendor"],
                         json={"name": "No User", "email": "nouser@example.com",
                               "password": "Password123!", "role": "organizer"})
    assert org_response.status_code == 403
    assert user_response.status_code == 403


def test_organizer_signup_creates_pending_request_not_approved_organization():
    response = call("post", "/auth/register", json={
        "name": "New Organizer", "email": "new.organizer@example.com",
        "password": "Password123!", "organization_name": "Pending Campus Club",
        "organization_type": "Student Club",
    })
    assert response.status_code == 201, response.text
    with SessionLocal() as db:
        request = db.scalar(select(OrganizationRequest).where(
            OrganizationRequest.organization_name == "Pending Campus Club"
        ))
        assert request is not None and request.status == "pending"
        assert db.scalar(select(Organization).where(
            Organization.name == "Pending Campus Club"
        )) is None


def test_vendor_deactivation_persists_and_blocks_new_bookings():
    ids, tokens = seed_world()
    response = call("patch", f"/services/{ids['service']}", tokens["vendor"],
                    json={"is_active": False})
    assert response.status_code == 200, response.text
    with SessionLocal() as db:
        service = db.get(Service, ids["service"])
        assert service is not None and service.is_active is False
    listed = call("get", "/services/", tokens["organizer"])
    assert listed.status_code == 200
    assert all(service["id"] != ids["service"] for service in listed.json())
    booking = call("post", "/bookings/", tokens["organizer"], json={
        "event_id": ids["event"], "vendor_id": ids["vendor"],
        "service_id": ids["service"], "amount": 1000, "status": "booked",
    })
    assert booking.status_code == 404


def test_service_deletion_is_soft_and_preserves_historical_booking():
    ids, tokens = seed_world()
    with SessionLocal() as db:
        booking = Booking(event_id=ids["event"], vendor_id=ids["vendor"],
                          service_id=ids["service"], amount=2500, status="completed")
        db.add(booking)
        db.commit()
        booking_id = booking.id
    response = call("delete", f"/services/{ids['service']}", tokens["admin"])
    assert response.status_code == 204, response.text
    with SessionLocal() as db:
        service = db.get(Service, ids["service"])
        booking = db.get(Booking, booking_id)
        assert service is not None and service.is_deleted and not service.is_active
        assert booking is not None and booking.status == "completed"


def test_admin_created_account_can_login_and_deleted_user_token_is_rejected():
    ids, tokens = seed_world()
    created = call("post", "/users/", tokens["admin"], json={
        "name": "Managed Organizer", "email": "managed.organizer@example.com",
        "password": "ManagedPassword123!", "role": "organizer",
        "organization_id": ids["organization"],
    })
    assert created.status_code == 201, created.text
    login = call("post", "/auth/login", data={
        "username": "managed.organizer@example.com", "password": "ManagedPassword123!",
    })
    assert login.status_code == 200, login.text
    deleted = call("delete", f"/users/{ids['vendor_user']}", tokens["admin"])
    assert deleted.status_code == 204, deleted.text
    old_token = call("get", "/auth/me", tokens["vendor"])
    assert old_token.status_code == 401
    relogin = call("post", "/auth/login", data={
        "username": "vendor@example.com", "password": "VendorPassword123!",
    })
    assert relogin.status_code == 401


def test_admin_can_approve_organization_request_and_only_then_create_org():
    ids, tokens = seed_world()
    registered = call("post", "/auth/register", json={
        "name": "Pending Organizer", "email": "pending.organizer@example.com",
        "password": "Password123!", "organization_name": "Approval Club",
        "organization_type": "Student Club",
    })
    assert registered.status_code == 201, registered.text
    with SessionLocal() as db:
        req = db.scalar(select(OrganizationRequest).where(
            OrganizationRequest.organization_name == "Approval Club"
        ))
        request_id = req.id
    denied = call("post", f"/organizations/requests/{request_id}/approve", tokens["organizer"])
    assert denied.status_code == 403
    approved = call("post", f"/organizations/requests/{request_id}/approve", tokens["admin"])
    assert approved.status_code == 200, approved.text
    assert approved.json()["status"] == "approved"
    with SessionLocal() as db:
        org = db.scalar(select(Organization).where(Organization.name == "Approval Club"))
        assert org is not None


def test_last_active_admin_cannot_be_deleted_and_foreign_keys_are_enabled():
    ids, tokens = seed_world()
    response = call("delete", f"/users/{ids['admin']}", tokens["admin"])
    assert response.status_code == 409
    with SessionLocal() as db:
        assert db.connection().exec_driver_sql("PRAGMA foreign_keys").scalar() == 1


def test_vendor_cannot_edit_another_vendors_service():
    ids, tokens = seed_world()
    with SessionLocal() as db:
        other_user = User(name="Other Vendor", email="other.vendor@example.com",
                          role="vendor", password_hash=hash_password("OtherPassword123!"),
                          is_active=True)
        db.add(other_user)
        db.flush()
        other_vendor = Vendor(vendor_name="Other Vendor", company_name="Other Co",
                              contact_number="9876501234", email=other_user.email,
                              address="Vellore", user_id=other_user.id, approval_status="approved")
        db.add(other_vendor)
        db.flush()
        other_service = Service(service_name="Other Vendor Service", category="Lighting",
                                vendor_owner_id=other_vendor.id, is_active=True, is_deleted=False)
        db.add(other_service)
        db.flush()
        other_vendor.services.append(other_service)
        db.commit()
        other_service_id = other_service.id
        token = create_access_token(other_user)
    response = call("patch", f"/services/{ids['service']}", token, json={"description": "Hijacked"})
    assert response.status_code == 403
    response = call("patch", f"/services/{other_service_id}", tokens["vendor"], json={"description": "Hijacked"})
    assert response.status_code == 403
