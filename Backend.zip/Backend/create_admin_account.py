"""Provision an administrator account from a trusted local terminal.

Run from Backend after configuring .env and before exposing the app publicly.
This is intentionally not an HTTP/public signup route.
"""
from getpass import getpass

from sqlalchemy import func, select

from app.database import Base, SessionLocal, engine
from app import models  # noqa: F401
from app.models import User
from app.security import hash_password

Base.metadata.create_all(bind=engine)
name = input("Administrator name: ").strip()
email = input("Administrator email: ").strip().lower()
password = getpass("Password (minimum 12 characters): ")
confirm = getpass("Confirm password: ")
if len(name) < 2:
    raise SystemExit("Name must contain at least 2 characters.")
if len(password) < 12:
    raise SystemExit("Use a password with at least 12 characters.")
if password != confirm:
    raise SystemExit("Passwords do not match.")

with SessionLocal() as db:
    if db.scalar(select(User.id).where(func.lower(User.email) == email)):
        raise SystemExit("An account with this email already exists. No changes were made.")
    user = User(name=name, email=email, role="admin", password_hash=hash_password(password))
    db.add(user)
    db.commit()
    print(f"Administrator account created for {email}.")
