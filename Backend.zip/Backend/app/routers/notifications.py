from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy import select, or_, and_
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Booking, Event, OrganizationRequest, ServiceRequest, Vendor, VendorOffer
from ..security import get_current_user
from ..models import User

router = APIRouter(prefix="/notifications", tags=["Notifications"])


def _item(item_id: str, title: str, message: str, kind: str, created_at: datetime | None = None) -> dict[str, Any]:
    return {
        "id": item_id,
        "title": title,
        "message": message,
        "kind": kind,
        "created_at": (created_at or datetime.utcnow()).isoformat(),
    }


@router.get("/")
def list_notifications(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Return role-scoped notifications derived from current EventHub records."""
    items: list[dict[str, Any]] = []

    if user.role == "admin":
        org_requests = db.scalars(select(OrganizationRequest).where(
            OrganizationRequest.status == "pending"
        ).order_by(OrganizationRequest.created_at.desc()).limit(10)).all()
        for req in org_requests:
            items.append(_item(
                f"org-request-{req.id}", "Organization request awaiting review",
                f"{req.organization_name} has requested organization affiliation.",
                "organization-request", req.created_at,
            ))
        vendor_apps = db.scalars(select(Vendor).where(
            Vendor.approval_status == "pending"
        ).order_by(Vendor.created_at.desc()).limit(10)).all()
        for vendor in vendor_apps:
            items.append(_item(
                f"vendor-application-{vendor.id}", "Vendor application awaiting review",
                f"{vendor.vendor_name} is waiting for approval.", "vendor-application", vendor.created_at,
            ))

    elif user.role == "organizer":
        requests = db.scalars(select(OrganizationRequest).where(
            OrganizationRequest.organizer_id == user.id,
            OrganizationRequest.status.in_(["approved", "rejected"]),
        ).order_by(OrganizationRequest.reviewed_at.desc()).limit(10)).all()
        for req in requests:
            title = "Organization request approved" if req.status == "approved" else "Organization request rejected"
            message = f"{req.organization_name}: {req.decision_note}" if req.decision_note else f"Your request for {req.organization_name} was {req.status}."
            items.append(_item(f"org-request-{req.id}-{req.status}", title, message, "organization-status", req.reviewed_at or req.created_at))
        event_ids = select(Event.id).where(Event.organizer_id == user.id)
        bookings = db.scalars(select(Booking).where(
            Booking.event_id.in_(event_ids), Booking.status.in_(["pending_confirmation", "confirmed", "booked", "cancelled", "completed", "rejected"])
        ).order_by(Booking.booking_date.desc()).limit(10)).all()
        for booking in bookings:
            event = db.get(Event, booking.event_id)
            service = booking.service
            label = {"pending_confirmation": "request sent", "booked": "confirmed", "cancelled": "cancelled", "completed": "completed", "rejected": "declined", "confirmed": "confirmed"}.get(booking.status, booking.status)
            items.append(_item(
                f"booking-{booking.id}-{booking.status}", f"Booking {label}",
                f"{service.service_name if service else 'Service'} for {event.event_name if event else 'your event'} is {label}.",
                "booking", booking.booking_date,
            ))

    elif user.role == "vendor":
        vendor = db.scalar(select(Vendor).where(Vendor.user_id == user.id))
        if vendor:
            # Incoming requests are service-specific. Resolve service IDs owned by or linked to this vendor.
            from ..models import Service, vendor_service
            service_ids = select(Service.id).where(Service.vendor_owner_id == vendor.id).union(
                select(vendor_service.c.service_id).where(vendor_service.c.vendor_id == vendor.id)
            )
            pending_request_ids = select(Booking.request_id).where(
                Booking.vendor_id == vendor.id,
                Booking.status == "pending_confirmation",
                Booking.request_id.is_not(None),
            )
            incoming = db.scalars(select(ServiceRequest).where(or_(
                and_(ServiceRequest.service_id.in_(service_ids), ServiceRequest.status == "open",
                     or_(ServiceRequest.vendor_id.is_(None), ServiceRequest.vendor_id == vendor.id)),
                and_(ServiceRequest.status == "pending_vendor_confirmation", or_(
                    ServiceRequest.vendor_id == vendor.id,
                    ServiceRequest.id.in_(pending_request_ids),
                )),
            )).order_by(ServiceRequest.created_at.desc()).limit(10)).all()
            for req in incoming:
                service = db.get(Service, req.service_id)
                event = db.get(Event, req.event_id)
                items.append(_item(
                    f"service-request-{req.id}", "New service request",
                    f"{event.event_name if event else 'An event'} needs {service.service_name if service else 'your service'}.",
                    "incoming-request", req.created_at,
                ))
            bookings = db.scalars(select(Booking).where(
                Booking.vendor_id == vendor.id,
                Booking.status.in_(["pending_confirmation", "confirmed", "booked", "cancelled", "completed", "rejected"]),
            ).order_by(Booking.booking_date.desc()).limit(10)).all()
            for booking in bookings:
                event = db.get(Event, booking.event_id)
                service = db.get(Service, booking.service_id)
                label = {"pending_confirmation": "request sent", "booked": "confirmed", "cancelled": "cancelled", "completed": "completed", "rejected": "declined", "confirmed": "confirmed"}.get(booking.status, booking.status)
                items.append(_item(
                    f"booking-{booking.id}-{booking.status}", f"Booking {label}",
                    f"{service.service_name if service else 'Service'} for {event.event_name if event else 'an event'} is {label}.",
                    "booking", booking.booking_date,
                ))

    items.sort(key=lambda item: item["created_at"], reverse=True)
    return items[:20]
