from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Booking, Review, Service, User, Vendor
from ..schemas import (
    VendorComparisonItem, VendorCreate, VendorResponse, VendorServiceResponse,
    VendorUpdate, VendorDecision, VendorApplicationResponse, ServiceCreate,
    ServiceResponse,
)
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/vendors", tags=["Vendors"])


def _own_vendor(db: Session, user: User) -> Vendor:
    vendor = db.scalar(select(Vendor).where(Vendor.user_id == user.id))
    if not vendor:
        raise HTTPException(status_code=404, detail="No vendor profile is linked to this account")
    return vendor


def _require_approved(vendor: Vendor) -> None:
    if vendor.approval_status != "approved":
        raise HTTPException(status_code=403, detail="Your vendor application must be approved before this action")


def _vendor_comparison(vendor: Vendor, service: Service, db: Session) -> dict:
    booking_rows = db.scalars(select(Booking).where(
        Booking.vendor_id == vendor.id, Booking.service_id == service.id
    )).all()
    booking_ids = [b.id for b in booking_rows]
    average_cost = round(sum(b.amount for b in booking_rows) / len(booking_rows), 2) if booking_rows else None
    ratings = db.scalars(select(Review.rating).where(Review.booking_id.in_(booking_ids))).all() if booking_ids else []
    average_rating = round(sum(ratings) / len(ratings), 2) if ratings else None
    return {
        "vendor_id": vendor.id, "vendor_name": vendor.vendor_name,
        "company_name": vendor.company_name, "contact_number": vendor.contact_number,
        "email": vendor.email, "address": vendor.address, "service_id": service.id,
        "service_name": service.service_name, "booking_count": len(booking_rows),
        "average_historical_cost": average_cost, "average_rating": average_rating,
        "review_count": len(ratings),
    }


@router.post("/", response_model=VendorResponse, status_code=status.HTTP_201_CREATED)
def create_vendor(payload: VendorCreate, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    """Admin-only creation of a business profile; it does not create a login account."""
    contact = payload.contact_number.strip()
    duplicate = db.scalar(select(Vendor).where(Vendor.contact_number == contact))
    if duplicate:
        raise HTTPException(status_code=409, detail="A vendor with this contact number already exists")
    email = str(payload.email).strip().lower() if payload.email else None
    if email and db.scalar(select(Vendor).where(func.lower(Vendor.email) == email)):
        raise HTTPException(status_code=409, detail="A vendor profile with this email already exists")
    data = payload.model_dump()
    linked_user_id = data.get("user_id")
    if linked_user_id is not None:
        linked_user = db.get(User, linked_user_id)
        if not linked_user or linked_user.role != "vendor":
            raise HTTPException(status_code=400, detail="Only an existing vendor-role account can be linked to a vendor profile")
        if db.scalar(select(Vendor).where(Vendor.user_id == linked_user_id)):
            raise HTTPException(status_code=409, detail="This account already has a vendor profile")
        if email and linked_user.email.lower() != email:
            raise HTTPException(status_code=400, detail="The profile email must match the selected vendor account")
        data["email"] = linked_user.email
        data["contact_number"] = contact or linked_user.phone
    data["contact_number"] = contact
    data["email"] = email or (db.get(User, linked_user_id).email if linked_user_id is not None else None)
    data["vendor_name"] = data["vendor_name"].strip()
    data["approval_status"] = "pending"
    vendor = Vendor(**data)
    db.add(vendor)
    db.commit()
    db.refresh(vendor)
    return vendor


@router.get("/applications", response_model=list[VendorApplicationResponse])
def get_vendor_applications(
    status_filter: str = "pending", db: Session = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    if status_filter not in {"pending", "approved", "rejected"}:
        raise HTTPException(status_code=400, detail="Invalid application status")
    return db.scalars(
        select(Vendor).where(Vendor.approval_status == status_filter).order_by(Vendor.created_at.desc())
    ).all()


@router.post("/{vendor_id}/approve", response_model=VendorApplicationResponse)
def approve_vendor(vendor_id: int, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    vendor = db.get(Vendor, vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor application not found")
    if vendor.approval_status == "approved":
        return vendor
    vendor.approval_status = "approved"
    vendor.rejection_reason = None
    vendor.reviewed_by = admin.id
    vendor.reviewed_at = datetime.utcnow()
    db.commit()
    db.refresh(vendor)
    return vendor


@router.post("/{vendor_id}/reject", response_model=VendorApplicationResponse)
def reject_vendor(
    vendor_id: int, payload: VendorDecision, db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    vendor = db.get(Vendor, vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor application not found")
    vendor.approval_status = "rejected"
    vendor.rejection_reason = payload.reason.strip() if payload.reason and payload.reason.strip() else None
    vendor.reviewed_by = admin.id
    vendor.reviewed_at = datetime.utcnow()
    for service in vendor.services:
        if service.vendor_owner_id == vendor.id:
            service.is_active = False
    db.commit()
    db.refresh(vendor)
    return vendor


@router.get("/me", response_model=VendorApplicationResponse)
def get_my_vendor_profile(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return _own_vendor(db, user)


@router.patch("/me", response_model=VendorApplicationResponse)
def update_my_vendor_profile(
    payload: VendorUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    vendor = _own_vendor(db, user)
    changes = payload.model_dump(exclude_unset=True)
    if "email" in changes and changes["email"]:
        normalized = str(changes["email"]).strip().lower()
        account = db.scalar(select(User).where(func.lower(User.email) == normalized, User.id != user.id))
        if account:
            raise HTTPException(status_code=409, detail="This email belongs to another account")
        vendor.email = normalized
        user.email = normalized
    if changes.get("contact_number"):
        contact = changes["contact_number"].strip()
        duplicate = db.scalar(select(Vendor).where(Vendor.contact_number == contact, Vendor.id != vendor.id))
        if duplicate:
            raise HTTPException(status_code=409, detail="A vendor with this contact number already exists")
        vendor.contact_number = contact
        user.phone = contact
    for key, value in changes.items():
        if key not in {"email", "contact_number"}:
            setattr(vendor, key, value.strip() if isinstance(value, str) else value)
    db.commit()
    db.refresh(vendor)
    return vendor


@router.post("/me/resubmit", response_model=VendorApplicationResponse)
def resubmit_my_vendor_application(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    vendor = _own_vendor(db, user)
    if vendor.approval_status != "rejected":
        raise HTTPException(status_code=409, detail="Only rejected applications can be resubmitted")
    vendor.approval_status = "pending"
    vendor.rejection_reason = None
    vendor.reviewed_by = None
    vendor.reviewed_at = None
    db.commit()
    db.refresh(vendor)
    return vendor


@router.get("/me/services", response_model=list[ServiceResponse])
def get_my_services(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    vendor = _own_vendor(db, user)
    return db.scalars(select(Service).where(
        Service.is_deleted.is_(False),
        or_(Service.vendor_owner_id == vendor.id, Service.vendors.any(Vendor.id == vendor.id))
    ).order_by(Service.category, Service.service_name)).all()


@router.post("/me/services", response_model=ServiceResponse, status_code=status.HTTP_201_CREATED)
def create_my_service(payload: ServiceCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    vendor = _own_vendor(db, user)
    name = payload.service_name.strip()
    if db.scalar(select(Service).where(Service.service_name.ilike(name))):
        raise HTTPException(status_code=409, detail="A service with this name already exists in the catalog")
    service = Service(**payload.model_dump(), vendor_owner_id=vendor.id, is_active=(vendor.approval_status == "approved"))
    db.add(service)
    db.flush()
    vendor.services.append(service)
    db.commit()
    db.refresh(service)
    return service


@router.get("/compare", response_model=list[VendorComparisonItem])
def compare_vendors(service_id: int, db: Session = Depends(get_db)):
    service = db.get(Service, service_id)
    if not service or not service.is_active:
        raise HTTPException(status_code=404, detail="Active service not found")
    vendors = db.scalars(select(Vendor).where(
        Vendor.approval_status == "approved",
        Vendor.services.any(and_(Service.id == service_id, Service.is_active.is_(True), Service.is_deleted.is_(False))),
    )).all()
    results = [_vendor_comparison(vendor, service, db) for vendor in vendors]
    results.sort(key=lambda x: (x["average_rating"] is not None, x["average_rating"] or 0, x["booking_count"]), reverse=True)
    return results


@router.get("/search", response_model=list[VendorResponse])
def search_vendors(
    q: str | None = None, category: str | None = None, service_id: int | None = None,
    db: Session = Depends(get_db),
):
    query = select(Vendor).where(
        Vendor.approval_status == "approved",
        Vendor.services.any(and_(Service.is_active.is_(True), Service.is_deleted.is_(False))),
    ).distinct()
    if q:
        pattern = f"%{q.strip()}%"
        query = query.where((Vendor.vendor_name.ilike(pattern)) | (Vendor.company_name.ilike(pattern)))
    if service_id is not None:
        query = query.where(Vendor.services.any(and_(Service.id == service_id, Service.is_active.is_(True))))
    if category:
        query = query.where(Vendor.services.any(and_(Service.category.ilike(f"%{category.strip()}%"), Service.is_active.is_(True))))
    return db.scalars(query.order_by(Vendor.vendor_name)).all()


@router.get("/", response_model=list[VendorResponse])
def get_vendors(q: str | None = None, service_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    query = select(Vendor)
    if user.role == "admin":
        pass
    elif user.role == "vendor":
        query = query.where(Vendor.user_id == user.id)
    else:
        query = query.where(
            Vendor.approval_status == "approved",
            Vendor.services.any(and_(Service.is_active.is_(True), Service.is_deleted.is_(False))),
        )
    if q:
        pattern = f"%{q.strip()}%"
        query = query.where((Vendor.vendor_name.ilike(pattern)) | (Vendor.company_name.ilike(pattern)))
    if service_id is not None:
        query = query.where(Vendor.services.any(Service.id == service_id))
    return db.scalars(query.order_by(Vendor.vendor_name)).all()


@router.get("/{vendor_id}", response_model=VendorResponse)
def get_vendor(vendor_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    vendor = db.get(Vendor, vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    if user.role != "admin" and not (
        user.role == "vendor" and vendor.user_id == user.id
    ) and vendor.approval_status != "approved":
        raise HTTPException(status_code=404, detail="Vendor not found")
    return vendor


@router.patch("/{vendor_id}", response_model=VendorResponse)
def update_vendor(
    vendor_id: int, payload: VendorUpdate, db: Session = Depends(get_db),
    user: User = Depends(require_admin),
):
    vendor = db.get(Vendor, vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    changes = payload.model_dump(exclude_unset=True)
    if changes.get("contact_number"):
        contact = changes["contact_number"].strip()
        duplicate = db.scalar(select(Vendor).where(Vendor.contact_number == contact, Vendor.id != vendor_id))
        if duplicate:
            raise HTTPException(status_code=409, detail="A vendor with this contact number already exists")
        changes["contact_number"] = contact
    if "email" in changes and changes["email"]:
        changes["email"] = str(changes["email"]).strip().lower()
    for key, value in changes.items():
        setattr(vendor, key, value.strip() if isinstance(value, str) else value)
    db.commit()
    db.refresh(vendor)
    return vendor


@router.post("/{vendor_id}/services/{service_id}", response_model=VendorServiceResponse, status_code=status.HTTP_201_CREATED)
def assign_service_to_vendor(vendor_id: int, service_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    vendor = db.get(Vendor, vendor_id)
    service = db.get(Service, service_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    if user.role != "admin" and not (user.role == "vendor" and vendor.user_id == user.id):
        raise HTTPException(status_code=403, detail="You can only manage services for your own profile")
    _require_approved(vendor)
    if service.vendor_owner_id not in (None, vendor.id) and user.role != "admin":
        raise HTTPException(status_code=403, detail="This service belongs to another vendor")
    if service not in vendor.services:
        vendor.services.append(service)
        db.commit()
    return {"vendor_id": vendor_id, "service_id": service_id}


@router.delete("/{vendor_id}/services/{service_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_service_from_vendor(vendor_id: int, service_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    vendor = db.get(Vendor, vendor_id)
    service = db.get(Service, service_id)
    if not vendor or not service:
        raise HTTPException(status_code=404, detail="Vendor or service not found")
    if user.role != "admin" and not (user.role == "vendor" and vendor.user_id == user.id):
        raise HTTPException(status_code=403, detail="You can only manage services for your own profile")
    if service not in vendor.services:
        raise HTTPException(status_code=404, detail="This service is not assigned to the vendor")
    if service.vendor_owner_id == vendor.id:
        service.is_active = False
    else:
        vendor.services.remove(service)
    db.commit()
    return None
