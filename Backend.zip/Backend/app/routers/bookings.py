from datetime import date
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select, func, text
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import Booking, Event, Service, ServiceRequest, User, Vendor, VendorOffer
from ..schemas import BookingCreate, BookingResponse, BookingUpdate
from ..security import get_current_user

router = APIRouter(prefix="/bookings", tags=["Bookings"])


@router.post("/", response_model=BookingResponse, status_code=status.HTTP_201_CREATED)
def create_booking(payload: BookingCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role == "vendor":
        raise HTTPException(status_code=403, detail="Vendors cannot create organizer bookings")
    if payload.status != "booked":
        raise HTTPException(status_code=422, detail="New bookings must start as booked; update status through the booking lifecycle")
    # Acquire SQLite's reserved write lock before checking availability so two
    # concurrent confirmations cannot both pass the same read-then-write check.
    if db.bind is not None and db.bind.dialect.name == "sqlite":
        db.execute(text("BEGIN IMMEDIATE"))
    event = db.get(Event, payload.event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role != "admin" and event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the event organizer or an admin can add bookings to this event")
    vendor = db.get(Vendor, payload.vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    if vendor.approval_status != "approved":
        raise HTTPException(status_code=409, detail="This vendor is not approved for new bookings")
    service = db.get(Service, payload.service_id)
    if not service or not service.is_active or service.is_deleted:
        raise HTTPException(status_code=404, detail="Active service not found")
    if service not in vendor.services:
        raise HTTPException(status_code=400, detail="This vendor is not registered for the selected service")
    existing = db.scalar(select(Booking).where(
        Booking.event_id == payload.event_id,
        Booking.vendor_id == payload.vendor_id,
        Booking.service_id == payload.service_id,
    ))
    if existing:
        raise HTTPException(status_code=409, detail="A booking already exists for this event/vendor/service combination")

    # The current schema has an event timestamp but no duration/capacity model.
    # Until that model exists, reserve the same vendor+service for at most one
    # active booking per calendar date; this is intentionally conservative.
    event_day = event.event_date.date()
    conflict = db.scalar(
        select(Booking.id).join(Event, Booking.event_id == Event.id).where(
            Booking.vendor_id == vendor.id,
            Booking.service_id == service.id,
            Booking.status == "booked",
            Booking.event_id != event.id,
            func.date(Event.event_date) == event_day.isoformat(),
        ).limit(1)
    )
    if conflict:
        raise HTTPException(status_code=409, detail="This service already has a confirmed booking on the event date")

    booking_data = payload.model_dump()
    if current_user.role == "organizer":
        booking_data["status"] = "pending_confirmation"
    booking = Booking(**booking_data)
    db.add(booking)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(status_code=409, detail="Booking could not be confirmed; availability may have changed")
    db.refresh(booking)
    return booking


@router.get("/", response_model=list[BookingResponse])
def get_bookings(
    event_id: int | None = None, vendor_id: int | None = None,
    status_filter: str | None = None, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = select(Booking).join(Event, Booking.event_id == Event.id)
    if current_user.role == "organizer":
        query = query.where(Event.organizer_id == current_user.id)
    elif current_user.role == "vendor":
        vendor = db.scalar(select(Vendor).where(Vendor.user_id == current_user.id))
        if not vendor:
            return []
        query = query.where(Booking.vendor_id == vendor.id)
    if event_id is not None:
        query = query.where(Booking.event_id == event_id)
    if vendor_id is not None:
        if current_user.role not in {"admin"} and not (
            current_user.role == "vendor" and db.scalar(select(Vendor.id).where(Vendor.user_id == current_user.id)) == vendor_id
        ):
            raise HTTPException(status_code=403, detail="You cannot view another vendor's bookings")
        query = query.where(Booking.vendor_id == vendor_id)
    if status_filter:
        query = query.where(Booking.status == status_filter)
    return db.scalars(query.order_by(Booking.booking_date.desc())).all()


@router.get("/{booking_id}", response_model=BookingResponse)
def get_booking(booking_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    booking = db.scalar(select(Booking).options(joinedload(Booking.event)).where(Booking.id == booking_id))
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    allowed = current_user.role == "admin" or (
        current_user.role == "organizer" and booking.event.organizer_id == current_user.id
    ) or (
        current_user.role == "vendor" and db.scalar(select(Vendor.id).where(Vendor.user_id == current_user.id)) == booking.vendor_id
    )
    if not allowed:
        raise HTTPException(status_code=404, detail="Booking not found")
    return booking


@router.patch("/{booking_id}", response_model=BookingResponse)
def update_booking(booking_id: int, payload: BookingUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    booking = db.scalar(select(Booking).options(joinedload(Booking.event)).where(Booking.id == booking_id))
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    changes = payload.model_dump(exclude_unset=True)
    requested_status = changes.get("status")
    vendor_id = db.scalar(select(Vendor.id).where(Vendor.user_id == current_user.id)) if current_user.role == "vendor" else None
    is_vendor_owner = current_user.role == "vendor" and vendor_id == booking.vendor_id
    is_organizer_owner = current_user.role == "organizer" and booking.event.organizer_id == current_user.id
    if current_user.role != "admin" and not is_vendor_owner and not is_organizer_owner:
        raise HTTPException(status_code=403, detail="You cannot manage this booking")
    if requested_status:
        if current_user.role == "vendor":
            if not is_vendor_owner or booking.status != "pending_confirmation" or requested_status not in {"booked", "rejected"}:
                raise HTTPException(status_code=409, detail="Vendors may only confirm or decline pending requests for their own services")
        elif current_user.role == "organizer":
            if requested_status != "cancelled" or booking.status not in {"pending_confirmation", "booked"}:
                raise HTTPException(status_code=409, detail="Organizers may cancel pending or confirmed bookings they own")
        elif current_user.role == "admin":
            if requested_status == "pending_confirmation":
                raise HTTPException(status_code=422, detail="Admins cannot move a booking back to pending")
        if booking.review is not None and requested_status == "cancelled":
            raise HTTPException(status_code=409, detail="A reviewed booking cannot be cancelled; preserve the historical record")
        if requested_status == "booked" and booking.status != "pending_confirmation" and current_user.role != "admin":
            raise HTTPException(status_code=409, detail="Only pending bookings can be confirmed")
        if requested_status == "booked" and current_user.role == "vendor":
            service = db.get(Service, booking.service_id)
            if not service or not service.is_active or service.is_deleted:
                raise HTTPException(status_code=409, detail="This service is no longer active and cannot be confirmed")
            event_day = booking.event.event_date.date().isoformat()
            conflict = db.scalar(select(Booking.id).join(Event, Booking.event_id == Event.id).where(
                Booking.vendor_id == booking.vendor_id,
                Booking.service_id == booking.service_id,
                Booking.status == "booked",
                Booking.id != booking.id,
                func.date(Event.event_date) == event_day,
            ).limit(1))
            if conflict:
                raise HTTPException(status_code=409, detail="This service already has a confirmed booking on the event date")
        booking.status = requested_status
        if booking.request_id:
            request = db.get(ServiceRequest, booking.request_id)
            if request:
                if requested_status == "booked":
                    request.status = "selected"
                    if booking.offer_id:
                        offer = db.get(VendorOffer, booking.offer_id)
                        if offer:
                            offer.status = "confirmed"
                elif requested_status in {"cancelled", "rejected"}:
                    request.status = "declined" if requested_status == "rejected" or current_user.role == "vendor" else "cancelled"
                    if booking.offer_id:
                        offer = db.get(VendorOffer, booking.offer_id)
                        if offer:
                            offer.status = "declined" if requested_status == "rejected" or current_user.role == "vendor" else "closed"
    if "amount" in changes:
        if current_user.role != "admin":
            raise HTTPException(status_code=403, detail="Only admins may adjust the recorded booking amount")
        booking.amount = changes["amount"]
    db.commit()
    db.refresh(booking)
    return booking
