import os

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Organization, OrganizationRequest, User, Vendor
from ..schemas import TokenResponse, OrganizerRegistrationCreate, UserResponse, VendorRegistrationCreate, VendorApplicationResponse
from ..security import create_access_token, get_current_user, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(payload: OrganizerRegistrationCreate, db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    configured_admin_email = os.getenv("ADMIN_EMAIL", "").strip().lower()
    if configured_admin_email and email == configured_admin_email:
        raise HTTPException(status_code=403, detail="This email is reserved for administrator provisioning")
    if db.scalar(select(User).where(func.lower(User.email) == email)):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    organization_name = payload.organization_name.strip()
    existing_org = db.scalar(select(Organization).where(Organization.name.ilike(organization_name)))
    user = User(
        name=payload.name.strip(),
        email=email,
        phone=payload.phone,
        role="organizer",
        password_hash=hash_password(payload.password),
        is_active=True,
    )
    try:
        db.add(user)
        db.flush()
        db.add(OrganizationRequest(
            organizer_id=user.id,
            organization_name=existing_org.name if existing_org else organization_name,
            organization_type=existing_org.organization_type if existing_org else payload.organization_type,
            contact_email=existing_org.contact_email if existing_org else (str(payload.organization_contact_email).lower() if payload.organization_contact_email else None),
            organization_id=existing_org.id if existing_org else None,
            status="pending",
        ))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An account or pending organization request already exists with these details")
    db.refresh(user)
    return user


@router.post("/register/vendor", response_model=VendorApplicationResponse, status_code=status.HTTP_201_CREATED)
def register_vendor(payload: VendorRegistrationCreate, db: Session = Depends(get_db)):
    """Create a vendor login and pending business profile atomically."""
    email = str(payload.email).strip().lower()
    configured_admin_email = os.getenv("ADMIN_EMAIL", "").strip().lower()
    if configured_admin_email and email == configured_admin_email:
        raise HTTPException(status_code=403, detail="This email is reserved for administrator provisioning")
    existing = db.scalar(select(User).where(func.lower(User.email) == email))
    if existing:
        raise HTTPException(status_code=409, detail="An account with this email already exists")

    phone = payload.contact_number.strip()
    duplicate_phone = db.scalar(select(Vendor).where(Vendor.contact_number == phone))
    if duplicate_phone:
        raise HTTPException(status_code=409, detail="A vendor with this contact number already exists")

    user = User(
        name=payload.vendor_name.strip(),
        email=email,
        phone=phone,
        role="vendor",
        password_hash=hash_password(payload.password),
    )
    try:
        db.add(user)
        db.flush()
        vendor = Vendor(
            vendor_name=payload.vendor_name.strip(),
            company_name=payload.company_name.strip() if payload.company_name else None,
            contact_number=phone,
            email=email,
            address=payload.address.strip(),
            user_id=user.id,
            approval_status="pending",
        )
        db.add(vendor)
        db.commit()
        db.refresh(vendor)
        return vendor
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An account or vendor profile with these details already exists")
    except Exception:
        db.rollback()
        raise


@router.post("/login", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    # OAuth2 form uses 'username'; enter the account email in that field.
    user = db.scalar(select(User).where(func.lower(User.email) == form.username.strip().lower()))
    if not user or not user.is_active or user.role not in {"admin", "organizer", "vendor"} or not user.password_hash or not verify_password(form.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return {"access_token": create_access_token(user), "token_type": "bearer", "user": user}


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user
