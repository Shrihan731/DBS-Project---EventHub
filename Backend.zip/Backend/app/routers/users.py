import secrets

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Event, Organization, OrganizationRequest, Review, ServiceRequest, User, Vendor
from ..schemas import AdminUserCreate, UserResponse, UserUpdate
from ..security import get_current_user, hash_password, require_admin

router = APIRouter(prefix="/users", tags=["Users"])


@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_user(
    payload: AdminUserCreate,
    db: Session = Depends(get_db),
    _admin: User = Depends(require_admin),
):
    """Create a login-enabled account with a selected role; admins only."""
    email = str(payload.email).lower()
    if db.scalar(select(User).where(func.lower(User.email) == email)):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    if payload.role != "organizer" and payload.organization_id is not None:
        raise HTTPException(status_code=422, detail="Only organizer accounts can be associated with an organization")
    organization = db.get(Organization, payload.organization_id) if payload.organization_id is not None else None
    if payload.organization_id is not None and organization is None:
        raise HTTPException(status_code=404, detail="Organization not found")
    new_user = User(
        name=payload.name.strip(),
        email=email,
        phone=payload.phone,
        role=payload.role,
        password_hash=hash_password(payload.password),
        is_active=True,
    )
    db.add(new_user)
    try:
        db.flush()
        if organization is not None:
            db.add(OrganizationRequest(
                organizer_id=new_user.id,
                organization_name=organization.name,
                organization_type=organization.organization_type,
                contact_email=organization.contact_email,
                organization_id=organization.id,
                status="approved",
                reviewed_by=_admin.id,
                reviewed_at=__import__("datetime").datetime.utcnow(),
            ))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    db.refresh(new_user)
    return new_user

@router.get("/", response_model=list[UserResponse])
def get_users(db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    return db.scalars(select(User).where(User.role != "deleted").order_by(User.id)).all()


@router.get("/{user_id}", response_model=UserResponse)
def get_user(user_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.id != user_id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="You can only view your own account")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.patch("/{user_id}", response_model=UserResponse)
def update_user(user_id: int, payload: UserUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.id != user_id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="You can only update your own account")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(user, key, value)
    db.commit()
    db.refresh(user)
    return user


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    user = db.get(User, user_id)
    if not user or user.role == "deleted":
        raise HTTPException(status_code=404, detail="User not found")
    if user.role == "admin":
        active_admins = db.scalar(select(func.count()).select_from(User).where(User.role == "admin", User.is_active.is_(True))) or 0
        if active_admins <= 1:
            raise HTTPException(status_code=409, detail="The last active administrator cannot be deleted")

    # Preserve business history by anonymizing referenced accounts; truly unreferenced
    # accounts are removed from the database. In either case old tokens stop working.
    references = (
        (db.scalar(select(func.count()).select_from(Event).where(Event.organizer_id == user.id)) or 0)
        + (db.scalar(select(func.count()).select_from(Review).where(Review.user_id == user.id)) or 0)
        + (db.scalar(select(func.count()).select_from(ServiceRequest).where(ServiceRequest.organizer_id == user.id)) or 0)
        + (db.scalar(select(func.count()).select_from(Vendor).where(Vendor.user_id == user.id)) or 0)
        + (db.scalar(select(func.count()).select_from(Vendor).where(Vendor.reviewed_by == user.id)) or 0)
        + (db.scalar(select(func.count()).select_from(OrganizationRequest).where(
            (OrganizationRequest.organizer_id == user.id) | (OrganizationRequest.reviewed_by == user.id)
        )) or 0)
    )
    if references:
        user.name = "Deleted account"
        user.email = f"deleted+{user.id}@invalid.eventhub"
        user.phone = None
        user.role = "deleted"
        user.password_hash = hash_password(secrets.token_urlsafe(48))
        user.is_active = False
    else:
        db.delete(user)
    db.commit()
    return None
