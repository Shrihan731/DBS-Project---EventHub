from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Organization, OrganizationRequest, User
from ..schemas import (OrganizationCreate, OrganizationResponse, OrganizationUpdate, OrganizationRequestCreate, OrganizationRequestDecision, OrganizationRequestResponse)
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/organizations", tags=["Organizations"])


@router.get("/requests", response_model=list[OrganizationRequestResponse])
def list_organization_requests(status_filter: str = "pending", db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    if status_filter not in {"pending", "approved", "rejected"}:
        raise HTTPException(status_code=400, detail="Invalid organization request status")
    return db.scalars(select(OrganizationRequest).where(OrganizationRequest.status == status_filter).order_by(OrganizationRequest.created_at.desc())).all()


@router.get("/requests/me", response_model=list[OrganizationRequestResponse])
def my_organization_requests(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if user.role != "organizer":
        raise HTTPException(status_code=403, detail="Organizer access required")
    return db.scalars(select(OrganizationRequest).where(OrganizationRequest.organizer_id == user.id).order_by(OrganizationRequest.created_at.desc())).all()


@router.post("/requests", response_model=OrganizationRequestResponse, status_code=status.HTTP_201_CREATED)
def create_organization_request(payload: OrganizationRequestCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if user.role != "organizer":
        raise HTTPException(status_code=403, detail="Only organizers can request organization affiliation")
    org_name = payload.organization_name.strip()
    existing_org = db.get(Organization, payload.existing_organization_id) if payload.existing_organization_id else db.scalar(select(Organization).where(Organization.name.ilike(org_name)))
    if payload.existing_organization_id and not existing_org:
        raise HTTPException(status_code=404, detail="Selected organization was not found")
    if existing_org:
        org_name = existing_org.name
    already_approved = db.scalar(select(OrganizationRequest).where(
        OrganizationRequest.organizer_id == user.id,
        OrganizationRequest.organization_name.ilike(org_name),
        OrganizationRequest.status == "approved",
    ))
    if already_approved:
        raise HTTPException(status_code=409, detail="Your affiliation with this organization is already approved")
    duplicate = db.scalar(select(OrganizationRequest).where(
        OrganizationRequest.organizer_id == user.id,
        OrganizationRequest.organization_name.ilike(org_name),
        OrganizationRequest.status == "pending",
    ))
    if duplicate:
        raise HTTPException(status_code=409, detail="You already have a pending request for this organization")
    req = OrganizationRequest(organizer_id=user.id, organization_name=org_name,
        organization_type=(existing_org.organization_type if existing_org else payload.organization_type),
        contact_email=(existing_org.contact_email if existing_org else (str(payload.contact_email).lower() if payload.contact_email else None)),
        organization_id=existing_org.id if existing_org else None, status="pending")
    db.add(req)
    db.commit()
    db.refresh(req)
    return req


@router.post("/requests/{request_id}/approve", response_model=OrganizationRequestResponse)
def approve_organization_request(request_id: int, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    req = db.get(OrganizationRequest, request_id)
    if not req:
        raise HTTPException(status_code=404, detail="Organization request not found")
    if req.status != "pending":
        raise HTTPException(status_code=409, detail="Only pending requests can be approved")
    org = db.get(Organization, req.organization_id) if req.organization_id else db.scalar(select(Organization).where(Organization.name.ilike(req.organization_name)))
    if not org:
        org = Organization(name=req.organization_name.strip(), organization_type=req.organization_type, contact_email=req.contact_email)
        db.add(org)
        db.flush()
    req.organization_id = org.id
    req.status = "approved"
    req.decision_note = None
    req.reviewed_by = admin.id
    req.reviewed_at = datetime.utcnow()
    db.commit()
    db.refresh(req)
    return req


@router.post("/requests/{request_id}/reject", response_model=OrganizationRequestResponse)
def reject_organization_request(request_id: int, payload: OrganizationRequestDecision, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    req = db.get(OrganizationRequest, request_id)
    if not req:
        raise HTTPException(status_code=404, detail="Organization request not found")
    if req.status != "pending":
        raise HTTPException(status_code=409, detail="Only pending requests can be rejected")
    req.status = "rejected"
    req.decision_note = payload.reason.strip() if payload.reason and payload.reason.strip() else None
    req.reviewed_by = admin.id
    req.reviewed_at = datetime.utcnow()
    db.commit()
    db.refresh(req)
    return req


@router.post("/", response_model=OrganizationResponse, status_code=status.HTTP_201_CREATED)
def create_organization(payload: OrganizationCreate, db: Session = Depends(get_db), _user: User = Depends(require_admin)):
    existing = db.scalar(select(Organization).where(Organization.name.ilike(payload.name.strip())))
    if existing:
        raise HTTPException(status_code=409, detail="Organization already exists")
    organization = Organization(**payload.model_dump())
    organization.name = organization.name.strip()
    db.add(organization)
    db.commit()
    db.refresh(organization)
    return organization


@router.get("/", response_model=list[OrganizationResponse])
def get_organizations(db: Session = Depends(get_db)):
    return db.scalars(select(Organization).order_by(Organization.name)).all()


@router.get("/{organization_id}", response_model=OrganizationResponse)
def get_organization(organization_id: int, db: Session = Depends(get_db)):
    organization = db.get(Organization, organization_id)
    if not organization:
        raise HTTPException(status_code=404, detail="Organization not found")
    return organization


@router.patch("/{organization_id}", response_model=OrganizationResponse)
def update_organization(organization_id: int, payload: OrganizationUpdate, db: Session = Depends(get_db), _user: User = Depends(require_admin)):
    organization = db.get(Organization, organization_id)
    if not organization:
        raise HTTPException(status_code=404, detail="Organization not found")
    changes = payload.model_dump(exclude_unset=True)
    if "name" in changes and changes["name"]:
        existing = db.scalar(select(Organization).where(Organization.name.ilike(changes["name"].strip()), Organization.id != organization_id))
        if existing:
            raise HTTPException(status_code=409, detail="Another organization already uses this name")
        changes["name"] = changes["name"].strip()
    for key, value in changes.items():
        setattr(organization, key, value)
    db.commit()
    db.refresh(organization)
    return organization

