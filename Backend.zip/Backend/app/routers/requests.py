from datetime import datetime, time, timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select, text, or_, and_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import Booking, Event, Service, ServiceRequest, User, Vendor, VendorOffer
from ..schemas import (
    ServiceRequestCreate, ServiceRequestResponse, BookingResponse,
    VendorOfferCreate, VendorOfferResponse,
)
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/requests", tags=["Service Requests"])


def _vendor_for_user(db: Session, user: User) -> Vendor:
    vendor = db.scalar(select(Vendor).where(Vendor.user_id == user.id))
    if not vendor:
        raise HTTPException(status_code=404, detail="No vendor profile is linked to this account")
    if vendor.approval_status != "approved":
        raise HTTPException(status_code=403, detail="Your vendor application must be approved first")
    return vendor


def _request_dict(db: Session, request: ServiceRequest, vendor_id: int | None = None) -> dict:
    event = db.get(Event, request.event_id)
    service = db.get(Service, request.service_id)
    organizer = db.get(User, request.organizer_id)
    target_vendor = db.get(Vendor, request.vendor_id) if request.vendor_id else None
    my_offer = db.scalar(select(VendorOffer).where(
        VendorOffer.request_id == request.id, VendorOffer.vendor_id == vendor_id
    )) if vendor_id is not None else None
    return {
        "id": request.id, "event_id": request.event_id, "service_id": request.service_id,
        "vendor_id": request.vendor_id, "vendor_name": target_vendor.vendor_name if target_vendor else None,
        "organizer_id": request.organizer_id, "requirements": request.requirements,
        "budget": request.budget, "start_at": request.start_at, "end_at": request.end_at,
        "status": request.status, "created_at": request.created_at,
        "event_name": event.event_name, "event_date": event.event_date, "venue": event.venue,
        "service_name": service.service_name, "organizer_name": organizer.name,
        "my_offer_id": my_offer.id if my_offer else None,
        "my_offer_status": my_offer.status if my_offer else None,
    }


def _offer_dict(offer: VendorOffer) -> dict:
    return {
        "id": offer.id, "request_id": offer.request_id, "vendor_id": offer.vendor_id,
        "amount": offer.amount, "inclusions": offer.inclusions, "message": offer.message,
        "status": offer.status, "created_at": offer.created_at,
        "vendor_name": offer.vendor.vendor_name, "company_name": offer.vendor.company_name,
        "approval_status": offer.vendor.approval_status,
    }


def _window_for_request(db: Session, request: ServiceRequest) -> tuple[datetime, datetime]:
    if request.start_at and request.end_at:
        return request.start_at, request.end_at
    event = db.get(Event, request.event_id)
    start = datetime.combine(event.event_date.date(), time.min)
    return start, start + timedelta(days=1)


def _has_conflict(db: Session, request: ServiceRequest, vendor_id: int) -> bool:
    requested_start, requested_end = _window_for_request(db, request)
    bookings = db.scalars(
        select(Booking)
        .options(joinedload(Booking.event), joinedload(Booking.request))
        .where(
            Booking.vendor_id == vendor_id,
            Booking.service_id == request.service_id,
            Booking.status == "booked",
        )
    ).unique().all()
    for booking in bookings:
        if booking.request and booking.request.start_at and booking.request.end_at:
            existing_start, existing_end = booking.request.start_at, booking.request.end_at
        else:
            existing_start = datetime.combine(booking.event.event_date.date(), time.min)
            existing_end = existing_start + timedelta(days=1)
        if requested_start < existing_end and existing_start < requested_end:
            return True
    return False


@router.post("/", response_model=ServiceRequestResponse, status_code=status.HTTP_201_CREATED)
def create_request(
    payload: ServiceRequestCreate, db: Session = Depends(get_db),
    organizer: User = Depends(get_current_user),
):
    if organizer.role != "organizer":
        raise HTTPException(status_code=403, detail="Only organizers can submit service requests")
    # Serialize availability check + request/booking creation on SQLite. This
    # prevents two simultaneous submissions from passing the same check.
    if db.bind is not None and db.bind.dialect.name == "sqlite":
        db.execute(text("BEGIN IMMEDIATE"))
    event = db.get(Event, payload.event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if event.organizer_id != organizer.id:
        raise HTTPException(status_code=403, detail="You can only request services for your own events")
    service = db.get(Service, payload.service_id)
    if not service or not service.is_active or service.is_deleted:
        raise HTTPException(status_code=404, detail="Active service not found")
    if bool(payload.start_at) != bool(payload.end_at):
        raise HTTPException(status_code=422, detail="Provide both start_at and end_at, or neither")
    if payload.start_at and payload.end_at:
        if payload.end_at <= payload.start_at:
            raise HTTPException(status_code=422, detail="end_at must be after start_at")
        if payload.start_at.date() != event.event_date.date() or payload.end_at.date() not in {
            event.event_date.date(), (event.event_date + timedelta(days=1)).date()
        }:
            raise HTTPException(status_code=422, detail="Requested service time must fall on the event date")
    target_vendor = None
    if payload.vendor_id is not None:
        target_vendor = db.get(Vendor, payload.vendor_id)
        if not target_vendor or target_vendor.approval_status != "approved":
            raise HTTPException(status_code=404, detail="Approved vendor not found")
        if service not in target_vendor.services:
            raise HTTPException(status_code=409, detail="This vendor does not offer the selected service")
        existing_active_booking = db.scalar(select(Booking).where(
            Booking.event_id == event.id,
            Booking.vendor_id == target_vendor.id,
            Booking.service_id == service.id,
            Booking.status.in_(("pending_confirmation", "booked")),
        ))
        if existing_active_booking:
            detail = (
                "A booking request for this event, vendor, and service is already awaiting vendor confirmation."
                if existing_active_booking.status == "pending_confirmation"
                else "This vendor and service are already confirmed for this event. Cancel the existing booking before requesting again."
            )
            db.rollback()
            raise HTTPException(status_code=409, detail=detail)
    else:
        eligible = db.scalar(select(Vendor.id).where(
            Vendor.approval_status == "approved",
            Vendor.services.any(Service.id == service.id),
        ).limit(1))
        if eligible is None:
            raise HTTPException(status_code=409, detail="No approved vendors currently offer this service")
    request = ServiceRequest(
        event_id=event.id, service_id=service.id, vendor_id=target_vendor.id if target_vendor else None,
        organizer_id=organizer.id,
        requirements=payload.requirements.strip() if payload.requirements else None,
        budget=payload.budget, start_at=payload.start_at, end_at=payload.end_at,
        status="pending_vendor_confirmation" if target_vendor else "open",
    )
    db.add(request)
    db.flush()
    if target_vendor:
        if _has_conflict(db, request, target_vendor.id):
            db.rollback()
            raise HTTPException(status_code=409, detail="This service is already booked for the requested time")
        db.add(Booking(
            event_id=event.id, vendor_id=target_vendor.id, service_id=service.id,
            amount=payload.budget if payload.budget is not None else 0,
            status="pending_confirmation", request_id=request.id,
        ))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="This vendor/service is already booked for this event or time. Refresh the booking list and try again.",
        )
    except Exception:
        db.rollback()
        raise
    db.refresh(request)
    return _request_dict(db, request)


@router.get("/mine", response_model=list[ServiceRequestResponse])
def get_my_requests(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if user.role not in {"organizer", "admin"}:
        raise HTTPException(status_code=403, detail="Only organizers can view organizer requests")
    query = select(ServiceRequest).order_by(ServiceRequest.created_at.desc())
    if user.role != "admin":
        query = query.where(ServiceRequest.organizer_id == user.id)
    return [_request_dict(db, item) for item in db.scalars(query).all()]


@router.get("/incoming", response_model=list[ServiceRequestResponse])
def get_incoming_requests(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    vendor = _vendor_for_user(db, user)
    service_ids = [service.id for service in vendor.services if service.is_active and not service.is_deleted]
    pending_booking_request_ids = select(Booking.request_id).where(
        Booking.vendor_id == vendor.id,
        Booking.status == "pending_confirmation",
        Booking.request_id.is_not(None),
    )
    requests = db.scalars(select(ServiceRequest).where(or_(
        and_(ServiceRequest.status == "open", ServiceRequest.service_id.in_(service_ids),
             or_(ServiceRequest.vendor_id.is_(None), ServiceRequest.vendor_id == vendor.id)),
        and_(ServiceRequest.status == "pending_vendor_confirmation", or_(
            ServiceRequest.vendor_id == vendor.id,
            ServiceRequest.id.in_(pending_booking_request_ids),
        )),
    )).order_by(ServiceRequest.created_at.desc())).all()
    return [_request_dict(db, item, vendor.id) for item in requests]


@router.post("/{request_id}/offers", response_model=VendorOfferResponse, status_code=status.HTTP_201_CREATED)
def submit_offer(
    request_id: int, payload: VendorOfferCreate, db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    vendor = _vendor_for_user(db, user)
    request = db.get(ServiceRequest, request_id)
    if not request or request.status != "open":
        raise HTTPException(status_code=404, detail="Open service request not found")
    service = db.get(Service, request.service_id)
    if not service or not service.is_active or service.is_deleted or service not in vendor.services:
        raise HTTPException(status_code=403, detail="This request does not match one of your active services")
    if db.scalar(select(VendorOffer.id).where(
        VendorOffer.request_id == request_id, VendorOffer.vendor_id == vendor.id
    )):
        raise HTTPException(status_code=409, detail="You have already submitted an offer for this request")
    offer = VendorOffer(
        request_id=request_id, vendor_id=vendor.id, amount=payload.amount,
        inclusions=payload.inclusions.strip() if payload.inclusions else None,
        message=payload.message.strip() if payload.message else None,
        status="submitted",
    )
    db.add(offer)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An offer for this request already exists")
    db.refresh(offer)
    return _offer_dict(offer)


@router.get("/{request_id}/offers", response_model=list[VendorOfferResponse])
def get_offers(
    request_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    request = db.get(ServiceRequest, request_id)
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    if user.role != "admin" and not (user.role == "organizer" and request.organizer_id == user.id):
        raise HTTPException(status_code=404, detail="Request not found")
    offers = db.scalars(select(VendorOffer).options(joinedload(VendorOffer.vendor)).where(
        VendorOffer.request_id == request_id
    ).order_by(VendorOffer.amount.asc(), VendorOffer.created_at.asc())).unique().all()
    return [_offer_dict(offer) for offer in offers]


@router.post("/{request_id}/offers/{offer_id}/select", response_model=BookingResponse)
def select_offer(
    request_id: int, offer_id: int, db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role not in {"organizer", "admin"}:
        raise HTTPException(status_code=403, detail="Only the organizer can select an offer")
    if db.bind is not None and db.bind.dialect.name == "sqlite":
        db.execute(text("BEGIN IMMEDIATE"))
    request = db.get(ServiceRequest, request_id)
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    if user.role != "admin" and request.organizer_id != user.id:
        raise HTTPException(status_code=403, detail="You can only select offers for your own requests")
    if request.status != "open":
        raise HTTPException(status_code=409, detail="This request has already been closed or confirmed")
    offer = db.scalar(select(VendorOffer).options(joinedload(VendorOffer.vendor)).where(
        VendorOffer.id == offer_id, VendorOffer.request_id == request_id
    ))
    if not offer or offer.status != "submitted":
        raise HTTPException(status_code=404, detail="Eligible offer not found")
    vendor = db.get(Vendor, offer.vendor_id)
    service = db.get(Service, request.service_id)
    if not vendor or vendor.approval_status != "approved" or not service or not service.is_active or service not in vendor.services:
        raise HTTPException(status_code=409, detail="The vendor or service is no longer eligible")
    if _has_conflict(db, request, vendor.id):
        raise HTTPException(status_code=409, detail="This service is no longer available for the requested time")
    booking = Booking(
        event_id=request.event_id, vendor_id=vendor.id, service_id=request.service_id,
        amount=offer.amount, status="pending_confirmation", request_id=request.id, offer_id=offer.id,
    )
    db.add(booking)
    offer.status = "selected"
    request.status = "pending_vendor_confirmation"
    for other in db.scalars(select(VendorOffer).where(
        VendorOffer.request_id == request.id, VendorOffer.id != offer.id
    )).all():
        if other.status == "submitted":
            other.status = "not_selected"
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Offer selection could not be confirmed; the request may already be booked")
    db.refresh(booking)
    return booking


@router.post("/{request_id}/decision", response_model=BookingResponse)
def decide_booking_request(
    request_id: int, payload: dict, db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    """Vendor accepts or declines a pending booking request; changes are shared across all role views."""
    vendor = _vendor_for_user(db, user)
    decision = str(payload.get("decision", "")).strip().lower()
    if decision not in {"accept", "decline"}:
        raise HTTPException(status_code=422, detail="decision must be 'accept' or 'decline'")
    request = db.get(ServiceRequest, request_id)
    if not request:
        raise HTTPException(status_code=404, detail="Booking request not found")
    booking = db.scalar(select(Booking).where(Booking.request_id == request_id))
    if not booking or booking.vendor_id != vendor.id:
        raise HTTPException(status_code=404, detail="Pending booking request not found for your business")
    if booking.status != "pending_confirmation":
        raise HTTPException(status_code=409, detail="This booking request has already been answered")
    if decision == "accept":
        service = db.get(Service, booking.service_id)
        if not service or not service.is_active or service.is_deleted:
            raise HTTPException(status_code=409, detail="This service is no longer active")
        if _has_conflict(db, request, vendor.id):
            raise HTTPException(status_code=409, detail="This service is no longer available for the requested time")
        booking.status = "booked"
        request.status = "selected"
        if booking.offer_id:
            offer = db.get(VendorOffer, booking.offer_id)
            if offer:
                offer.status = "confirmed"
    else:
        booking.status = "rejected"
        request.status = "declined"
        if booking.offer_id:
            offer = db.get(VendorOffer, booking.offer_id)
            if offer:
                offer.status = "declined"
    db.commit()
    db.refresh(booking)
    return booking


@router.post("/{request_id}/cancel", response_model=ServiceRequestResponse)
def cancel_request(
    request_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    request = db.get(ServiceRequest, request_id)
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    if user.role != "admin" and not (user.role == "organizer" and request.organizer_id == user.id):
        raise HTTPException(status_code=404, detail="Request not found")
    if request.status not in {"open", "pending_vendor_confirmation"}:
        raise HTTPException(status_code=409, detail="Only pending requests can be cancelled")
    request.status = "cancelled"
    if request.booking and request.booking.status == "pending_confirmation":
        request.booking.status = "cancelled"
    for offer in request.offers:
        if offer.status in {"submitted", "selected"}:
            offer.status = "closed"
    db.commit()
    db.refresh(request)
    return _request_dict(db, request)
