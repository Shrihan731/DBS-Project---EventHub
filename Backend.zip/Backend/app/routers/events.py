from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Booking, Event, Organization, OrganizationRequest, ServiceRequest, User
from ..schemas import EventCreate, EventResponse, EventUpdate
from ..security import get_current_user

router = APIRouter(prefix="/events", tags=["Events"])


@router.post("/", response_model=EventResponse, status_code=status.HTTP_201_CREATED)
def create_event(payload: EventCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role == "vendor":
        raise HTTPException(status_code=403, detail="Vendor accounts cannot create organizer events")
    organizer = db.get(User, payload.organizer_id)
    if not organizer:
        raise HTTPException(status_code=404, detail="Organizer/user not found")
    if current_user.role != "admin" and payload.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="You can only create events under your own user account")
    organization = db.get(Organization, payload.organization_id)
    if not organization:
        raise HTTPException(status_code=404, detail="Organization not found")
    if current_user.role == "organizer":
        affiliation = db.scalar(select(OrganizationRequest.id).where(
            OrganizationRequest.organizer_id == current_user.id,
            OrganizationRequest.organization_id == organization.id,
            OrganizationRequest.status == "approved",
        ))
        if not affiliation:
            raise HTTPException(status_code=403, detail="Your organization affiliation must be approved before creating events for it")
    event = Event(**payload.model_dump())
    db.add(event)
    db.commit()
    db.refresh(event)
    return event


@router.get("/", response_model=list[EventResponse])
def get_events(organization_id: int | None = None, event_type: str | None = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    query = select(Event)
    if current_user.role == "organizer":
        query = query.where(Event.organizer_id == current_user.id)
    elif current_user.role == "vendor":
        from ..models import Booking, Vendor
        vendor = db.scalar(select(Vendor).where(Vendor.user_id == current_user.id))
        if not vendor:
            return []
        query = query.join(Booking, Booking.event_id == Event.id).where(Booking.vendor_id == vendor.id).distinct()
    if organization_id is not None:
        query = query.where(Event.organization_id == organization_id)
    if event_type:
        query = query.where(Event.event_type.ilike(f"%{event_type.strip()}%"))
    return db.scalars(query.order_by(Event.event_date)).all()


@router.get("/{event_id}", response_model=EventResponse)
def get_event(event_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role == "organizer" and event.organizer_id != current_user.id:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role == "vendor":
        from ..models import Booking, Vendor
        vendor = db.scalar(select(Vendor).where(Vendor.user_id == current_user.id))
        if not vendor or not db.scalar(select(Booking.id).where(Booking.event_id == event.id, Booking.vendor_id == vendor.id)):
            raise HTTPException(status_code=404, detail="Event not found")
    return event


@router.patch("/{event_id}", response_model=EventResponse)
def update_event(event_id: int, payload: EventUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role != "admin" and event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the event organizer or an admin can edit this event")
    changes = payload.model_dump(exclude_unset=True)
    if "organizer_id" in changes and changes["organizer_id"] is not None and not db.get(User, changes["organizer_id"]):
        raise HTTPException(status_code=404, detail="Organizer/user not found")
    if "organization_id" in changes and changes["organization_id"] is not None and not db.get(Organization, changes["organization_id"]):
        raise HTTPException(status_code=404, detail="Organization not found")
    if current_user.role != "admin":
        changes.pop("organizer_id", None)
        if "organization_id" in changes and changes["organization_id"] is not None:
            affiliation = db.scalar(select(OrganizationRequest.id).where(
                OrganizationRequest.organizer_id == current_user.id,
                OrganizationRequest.organization_id == changes["organization_id"],
                OrganizationRequest.status == "approved",
            ))
            if not affiliation:
                raise HTTPException(status_code=403, detail="You can only associate events with your approved organization")
    for key, value in changes.items():
        setattr(event, key, value)
    db.commit()
    db.refresh(event)
    return event


@router.delete("/{event_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_event(event_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role != "admin" and event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the event organizer or an admin can delete this event")
    if db.scalar(select(Booking.id).where(Booking.event_id == event.id).limit(1)) or db.scalar(
        select(ServiceRequest.id).where(ServiceRequest.event_id == event.id).limit(1)
    ):
        raise HTTPException(status_code=409, detail="This event has booking or service-request history. Cancel or resolve its records before deleting the event.")
    db.delete(event)
    db.commit()
    return None
