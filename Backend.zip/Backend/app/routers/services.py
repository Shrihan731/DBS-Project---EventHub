from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Service, User, Vendor
from ..schemas import ServiceCreate, ServiceResponse, ServiceUpdate
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/services", tags=["Services"])


@router.post("/", response_model=ServiceResponse, status_code=status.HTTP_201_CREATED)
def create_service(payload: ServiceCreate, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    name = payload.service_name.strip()
    if db.scalar(select(Service).where(Service.service_name.ilike(name))):
        raise HTTPException(status_code=409, detail="Service already exists")
    data = payload.model_dump()
    data["service_name"] = name
    service = Service(**data, is_active=True)
    db.add(service)
    db.commit()
    db.refresh(service)
    return service


@router.get("/", response_model=list[ServiceResponse])
def get_services(category: str | None = None, q: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    query = select(Service)
    if user.role == "admin":
        pass
    elif user.role == "vendor":
        vendor = db.scalar(select(Vendor).where(Vendor.user_id == user.id))
        if not vendor:
            return []
        query = query.where(Service.is_deleted.is_(False), or_(
            Service.vendor_owner_id == vendor.id,
            and_(Service.vendor_owner_id.is_(None), Service.vendors.any(Vendor.id == vendor.id)),
        ))
    else:
        query = query.where(
            Service.is_active.is_(True),
            Service.is_deleted.is_(False),
            or_(Service.vendor_owner_id.is_(None), Service.owner.has(Vendor.approval_status == "approved")),
        )
    if category:
        query = query.where(Service.category.ilike(f"%{category.strip()}%"))
    if q:
        query = query.where(Service.service_name.ilike(f"%{q.strip()}%"))
    return db.scalars(query.order_by(Service.category, Service.service_name)).all()


@router.get("/{service_id}", response_model=ServiceResponse)
def get_service(service_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    service = db.get(Service, service_id)
    if not service or (service.is_deleted and user.role != "admin"):
        raise HTTPException(status_code=404, detail="Service not found")
    if user.role != "admin":
        if user.role == "vendor":
            vendor = db.scalar(select(Vendor).where(Vendor.user_id == user.id))
            if not vendor or (service.vendor_owner_id != vendor.id and service not in vendor.services):
                raise HTTPException(status_code=404, detail="Service not found")
        elif not service.is_active or (service.vendor_owner_id is not None and (not service.owner or service.owner.approval_status != "approved")):
            raise HTTPException(status_code=404, detail="Service not found")
    return service


@router.patch("/{service_id}", response_model=ServiceResponse)
def update_service(service_id: int, payload: ServiceUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    service = db.get(Service, service_id)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    if service.is_deleted:
        raise HTTPException(status_code=409, detail="Deleted services cannot be edited or reactivated")
    if user.role != "admin":
        vendor = db.scalar(select(Vendor).where(Vendor.user_id == user.id)) if user.role == "vendor" else None
        if not vendor or service.vendor_owner_id != vendor.id:
            raise HTTPException(status_code=403, detail="You can only edit services owned by your vendor profile")
        changes = payload.model_dump(exclude_unset=True)
        if vendor.approval_status != "approved" and changes.get("is_active") is True:
            raise HTTPException(status_code=403, detail="Your vendor application must be approved to activate services")
        if vendor.approval_status != "approved":
            changes["is_active"] = False
    else:
        changes = payload.model_dump(exclude_unset=True)
    if changes.get("service_name"):
        name = changes["service_name"].strip()
        duplicate = db.scalar(select(Service).where(Service.service_name.ilike(name), Service.id != service_id))
        if duplicate:
            raise HTTPException(status_code=409, detail="Another service already uses this name")
        changes["service_name"] = name
    for key, value in changes.items():
        setattr(service, key, value.strip() if isinstance(value, str) else value)
    db.commit()
    db.refresh(service)
    return service


@router.delete("/{service_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_service(service_id: int, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    service = db.get(Service, service_id)
    if not service or service.is_deleted:
        raise HTTPException(status_code=404, detail="Service not found")
    # Soft-delete to preserve booking, offer and audit history while removing the
    # service from discovery and preventing any new bookings.
    service.is_active = False
    service.is_deleted = True
    db.commit()
    return None
