from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Booking, Event, Organization, Review, Service, User, Vendor
from ..security import require_admin
from ..schemas import DashboardSummary

router = APIRouter(prefix="/analytics", tags=["Analytics"])


def _count(db: Session, model) -> int:
    return db.scalar(select(func.count()).select_from(model)) or 0


@router.get("/summary", response_model=DashboardSummary)
def dashboard_summary(db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    return DashboardSummary(
        users=_count(db, User),
        organizations=_count(db, Organization),
        events=_count(db, Event),
        vendors=_count(db, Vendor),
        services=_count(db, Service),
        bookings=_count(db, Booking),
        completed_bookings=db.scalar(select(func.count()).select_from(Booking).where(Booking.status == "completed")) or 0,
        reviews=_count(db, Review),
    )


@router.get("/popular-vendors")
def popular_vendors(limit: int = 5, db: Session = Depends(get_db), _admin: User = Depends(require_admin)):
    limit = max(1, min(limit, 20))
    rows = db.execute(
        select(Vendor.id, Vendor.vendor_name, func.count(Booking.id).label("booking_count"))
        .outerjoin(Booking, Booking.vendor_id == Vendor.id)
        .group_by(Vendor.id, Vendor.vendor_name)
        .order_by(func.count(Booking.id).desc(), Vendor.vendor_name)
        .limit(limit)
    ).all()
    return [{"vendor_id": r.id, "vendor_name": r.vendor_name, "booking_count": r.booking_count} for r in rows]
