import os
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, inspect, select, text

from .database import Base, SessionLocal, engine
from . import models  # noqa: F401 - register all ORM models before create_all
from .routers import analytics, auth, bookings, events, notifications, organizations, requests, reviews, services, users, vendors


# Back up an existing SQLite file before the startup migration changes its schema.
# The backup is only created when a required column/table is missing.
if engine.dialect.name == "sqlite" and engine.url.database and engine.url.database != ":memory:":
    database_path = Path(engine.url.database).expanduser()
    if not database_path.is_absolute():
        database_path = (Path.cwd() / database_path).resolve()
    if database_path.exists():
        preflight = inspect(engine)
        tables_before = set(preflight.get_table_names())
        needs_migration = "organization_requests" not in tables_before
        if "service_requests" in tables_before:
            needs_migration = needs_migration or "vendor_id" not in {c["name"] for c in preflight.get_columns("service_requests")}
        if "users" in tables_before:
            needs_migration = needs_migration or "is_active" not in {c["name"] for c in preflight.get_columns("users")}
            with engine.connect() as connection:
                role_values = connection.execute(text("SELECT role FROM users")).scalars().all()
            needs_migration = needs_migration or any(value and value != value.strip().lower() for value in role_values)
        if "services" in tables_before:
            needs_migration = needs_migration or "is_deleted" not in {c["name"] for c in preflight.get_columns("services")}
        if "bookings" in tables_before:
            legacy_uniques = preflight.get_unique_constraints("bookings")
            needs_migration = needs_migration or any(
                set(item.get("column_names") or []) == {"event_id", "vendor_id", "service_id"}
                for item in legacy_uniques
            )
        if needs_migration:
            backup_path = database_path.with_name(
                f"{database_path.stem}.pre_role_redesign_{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak"
            )
            shutil.copy2(database_path, backup_path)

# Create missing tables, then make a small backward-compatible SQLite migration.
Base.metadata.create_all(bind=engine)


def _migrate_booking_uniqueness() -> None:
    """Allow rebooking after cancellation while preventing duplicate active bookings.

    Older databases used a table-level UNIQUE(event_id, vendor_id, service_id),
    which also blocked legitimate historical/retry bookings after cancellation.
    Rebuild only that table, preserving every row and all foreign-key relationships.
    """
    if engine.dialect.name != "sqlite" or not engine.url.database or engine.url.database == ":memory:":
        return
    db_path = Path(engine.url.database).expanduser()
    if not db_path.is_absolute():
        db_path = (Path.cwd() / db_path).resolve()
    if not db_path.exists():
        return

    conn = sqlite3.connect(str(db_path))
    try:
        table_row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='bookings'"
        ).fetchone()
        if not table_row:
            return
        indexes = conn.execute("PRAGMA index_list('bookings')").fetchall()
        has_legacy_unique = False
        for index_row in indexes:
            # PRAGMA index_list columns: seq, name, unique, origin, partial
            if not index_row[2] or (len(index_row) > 4 and index_row[4]):
                # Ignore partial unique indexes; the new active-booking index is
                # expected and must not trigger this legacy-schema migration.
                continue
            index_name = index_row[1]
            index_columns = [
                row[2] for row in conn.execute(f"PRAGMA index_info('{index_name}')").fetchall()
            ]
            if set(index_columns) == {"event_id", "vendor_id", "service_id"}:
                has_legacy_unique = True
                break

        conn.execute("PRAGMA foreign_keys=OFF")
        if has_legacy_unique:
            conn.execute("BEGIN")
            conn.execute("DROP TABLE IF EXISTS bookings_rebuild")
            conn.execute("""
                CREATE TABLE bookings_rebuild (
                    id INTEGER NOT NULL PRIMARY KEY,
                    event_id INTEGER NOT NULL REFERENCES events(id),
                    vendor_id INTEGER NOT NULL REFERENCES vendors(id),
                    service_id INTEGER NOT NULL REFERENCES services(id),
                    booking_date DATETIME,
                    request_id INTEGER UNIQUE REFERENCES service_requests(id),
                    offer_id INTEGER UNIQUE REFERENCES vendor_offers(id),
                    amount FLOAT NOT NULL,
                    status VARCHAR(30) NOT NULL
                )
            """)
            existing_columns = {
                row[1] for row in conn.execute("PRAGMA table_info('bookings')").fetchall()
            }
            required_columns = {
                "id", "event_id", "vendor_id", "service_id", "booking_date",
                "request_id", "offer_id", "amount", "status",
            }
            if not required_columns.issubset(existing_columns):
                conn.rollback()
                raise RuntimeError(
                    "Cannot safely migrate bookings: expected columns are missing. "
                    "Restore from the automatic database backup and inspect the schema."
                )
            columns = ", ".join(sorted(required_columns))
            conn.execute(f"INSERT INTO bookings_rebuild ({columns}) SELECT {columns} FROM bookings")
            conn.execute("DROP TABLE bookings")
            conn.execute("ALTER TABLE bookings_rebuild RENAME TO bookings")
            conn.commit()

        # Enforce uniqueness only for active bookings. Cancelled/rejected rows remain
        # in history and no longer prevent a new request for the same combination.
        duplicate_active = conn.execute("""
            SELECT 1 FROM bookings
            WHERE status IN ('pending_confirmation', 'booked')
            GROUP BY event_id, vendor_id, service_id
            HAVING COUNT(*) > 1 LIMIT 1
        """).fetchone()
        if not duplicate_active:
            conn.execute("""
                CREATE UNIQUE INDEX IF NOT EXISTS uq_active_booking_event_vendor_service
                ON bookings(event_id, vendor_id, service_id)
                WHERE status IN ('pending_confirmation', 'booked')
            """)
        conn.execute("CREATE INDEX IF NOT EXISTS ix_bookings_id ON bookings(id)")
        conn.commit()
        conn.execute("PRAGMA foreign_keys=ON")
        violations = conn.execute("PRAGMA foreign_key_check").fetchall()
        if violations:
            raise RuntimeError(
                "Booking schema migration detected foreign-key violations; "
                "the original database backup has been retained."
            )
    finally:
        conn.close()


_migrate_booking_uniqueness()
if engine.dialect.name == "sqlite":
    inspector = inspect(engine)
    if "users" in inspector.get_table_names():
        user_columns = {column["name"] for column in inspector.get_columns("users")}
        with engine.begin() as connection:
            if "password_hash" not in user_columns:
                connection.execute(text("ALTER TABLE users ADD COLUMN password_hash VARCHAR(255)"))
            if "is_active" not in user_columns:
                connection.execute(text("ALTER TABLE users ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT 1"))
            connection.execute(text("UPDATE users SET role = lower(trim(role)) WHERE role IS NOT NULL"))
    if "services" in inspector.get_table_names():
        service_columns = {column["name"] for column in inspector.get_columns("services")}
        if "is_deleted" not in service_columns:
            with engine.begin() as connection:
                connection.execute(text("ALTER TABLE services ADD COLUMN is_deleted BOOLEAN NOT NULL DEFAULT 0"))
    if "service_requests" in inspector.get_table_names():
        request_columns = {column["name"] for column in inspector.get_columns("service_requests")}
        if "vendor_id" not in request_columns:
            with engine.begin() as connection:
                connection.execute(text("ALTER TABLE service_requests ADD COLUMN vendor_id INTEGER REFERENCES vendors(id)"))
                connection.execute(text("CREATE INDEX IF NOT EXISTS ix_service_requests_vendor_id ON service_requests(vendor_id)"))

# Fail clearly if an existing SQLite database has not received the controlled
# vendor-onboarding migration. create_all() does not alter existing tables.
if engine.dialect.name == "sqlite":
    inspector = inspect(engine)
    if "vendors" in inspector.get_table_names() and "services" in inspector.get_table_names():
        vendor_columns = {column["name"] for column in inspector.get_columns("vendors")}
        service_columns = {column["name"] for column in inspector.get_columns("services")}
        required_vendor_columns = {"user_id", "approval_status", "rejection_reason", "reviewed_by", "reviewed_at", "created_at"}
        required_service_columns = {"vendor_owner_id", "is_active"}
        booking_columns = {column["name"] for column in inspector.get_columns("bookings")} if "bookings" in inspector.get_table_names() else set()
        required_booking_columns = {"request_id", "offer_id"}
        required_tables = {"service_requests", "vendor_offers"}
        if (not required_vendor_columns.issubset(vendor_columns)
                or not required_service_columns.issubset(service_columns)
                or not required_booking_columns.issubset(booking_columns)
                or not required_tables.issubset(set(inspector.get_table_names()))):
            raise RuntimeError(
                "EventHub database schema needs the vendor onboarding migration. "
                "From Backend run: python migrate_vendor_onboarding.py"
            )

# Optional administrator promotion for an account provisioned through a trusted process.
admin_email = os.getenv("ADMIN_EMAIL", "").strip().lower()
if admin_email:
    with SessionLocal() as db:
        admin_user = db.scalar(select(models.User).where(func.lower(models.User.email) == admin_email))
        if admin_user and admin_user.role != "admin":
            admin_user.role = "admin"
            db.commit()

app = FastAPI(
    title="EventHub API",
    description=(
        "EventHub campus event marketplace with vendor onboarding, admin approval, "
        "service requests, offers, and booking availability."
    ),
    version="1.1.0",
)

# Allow the local Vite frontend to call the API during development.
# localhost and 127.0.0.1 are distinct browser origins.
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1|192\.168(?:\.\d{1,3}){2}|10(?:\.\d{1,3}){3}|172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(:\d+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(organizations.router)
app.include_router(events.router)
app.include_router(vendors.router)
app.include_router(services.router)
app.include_router(bookings.router)
app.include_router(requests.router)
app.include_router(reviews.router)
app.include_router(analytics.router)
app.include_router(notifications.router)

static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/", include_in_schema=False)
def root():
    return {"message": "Welcome to EventHub API", "status": "running", "docs": "/docs", "ui": "/ui"}


@app.get("/ui", include_in_schema=False)
def ui():
    return FileResponse(static_dir / "index.html")


@app.get("/health", tags=["System"])
def health_check():
    return {"status": "healthy"}
