from datetime import datetime

from sqlalchemy import (
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    Index,
    String,
    Table,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


# M:N relationship between Vendor and Service.
vendor_service = Table(
    "vendor_service",
    Base.metadata,
    Column("vendor_id", ForeignKey("vendors.id", ondelete="CASCADE"), primary_key=True),
    Column("service_id", ForeignKey("services.id", ondelete="CASCADE"), primary_key=True),
)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str] = mapped_column(String(150), unique=True, nullable=False, index=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    role: Mapped[str] = mapped_column(String(30), default="organizer", nullable=False)
    # Nullable for compatibility with users created before authentication was added.
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)

    events: Mapped[list["Event"]] = relationship(back_populates="organizer")
    reviews: Mapped[list["Review"]] = relationship(back_populates="user")
    vendor_profile: Mapped["Vendor | None"] = relationship(back_populates="user", uselist=False, foreign_keys="Vendor.user_id")


class Organization(Base):
    __tablename__ = "organizations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(150), unique=True, nullable=False)
    organization_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    contact_email: Mapped[str | None] = mapped_column(String(150), nullable=True)

    events: Mapped[list["Event"]] = relationship(back_populates="organization")


class OrganizationRequest(Base):
    __tablename__ = "organization_requests"
    __table_args__ = (UniqueConstraint("organizer_id", "organization_name", "status", name="uq_org_request_user_name_status"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    organizer_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    organization_name: Mapped[str] = mapped_column(String(150), nullable=False)
    organization_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    contact_email: Mapped[str | None] = mapped_column(String(150), nullable=True)
    organization_id: Mapped[int | None] = mapped_column(ForeignKey("organizations.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    decision_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)

    organizer: Mapped["User"] = relationship(foreign_keys=[organizer_id])
    organization: Mapped["Organization | None"] = relationship(foreign_keys=[organization_id])
    reviewer: Mapped["User | None"] = relationship(foreign_keys=[reviewed_by])


class Event(Base):
    __tablename__ = "events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    event_name: Mapped[str] = mapped_column(String(150), nullable=False)
    event_type: Mapped[str] = mapped_column(String(80), nullable=False)
    event_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    venue: Mapped[str] = mapped_column(String(200), nullable=False)
    expected_attendees: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    organizer_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    organization_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), nullable=False)

    organizer: Mapped["User"] = relationship(back_populates="events")
    organization: Mapped["Organization"] = relationship(back_populates="events")
    bookings: Mapped[list["Booking"]] = relationship(
        back_populates="event",
        cascade="all, delete-orphan",
    )


class Vendor(Base):
    __tablename__ = "vendors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    vendor_name: Mapped[str] = mapped_column(String(150), nullable=False)
    company_name: Mapped[str | None] = mapped_column(String(150), nullable=True)
    contact_number: Mapped[str] = mapped_column(String(20), nullable=False)
    email: Mapped[str | None] = mapped_column(String(150), nullable=True)
    address: Mapped[str | None] = mapped_column(String(250), nullable=True)
    # Nullable for legacy/admin-created profiles that predate vendor self-registration.
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), unique=True, nullable=True, index=True)
    approval_status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    rejection_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    user: Mapped["User | None"] = relationship(back_populates="vendor_profile", foreign_keys=[user_id])
    reviewer: Mapped["User | None"] = relationship(foreign_keys=[reviewed_by])

    services: Mapped[list["Service"]] = relationship(
        secondary=vendor_service,
        back_populates="vendors",
    )
    bookings: Mapped[list["Booking"]] = relationship(back_populates="vendor")


class Service(Base):
    __tablename__ = "services"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    service_name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    category: Mapped[str] = mapped_column(String(80), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    # A service can remain a shared catalog item or be owned by one vendor.
    vendor_owner_id: Mapped[int | None] = mapped_column(ForeignKey("vendors.id"), nullable=True, index=True)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)
    is_deleted: Mapped[bool] = mapped_column(default=False, nullable=False)

    owner: Mapped["Vendor | None"] = relationship(foreign_keys=[vendor_owner_id])
    vendors: Mapped[list["Vendor"]] = relationship(
        secondary=vendor_service,
        back_populates="services",
    )
    bookings: Mapped[list["Booking"]] = relationship(back_populates="service")

    @property
    def vendor_names(self) -> list[str]:
        names = [vendor.vendor_name for vendor in self.vendors]
        if self.owner and self.owner.vendor_name not in names:
            names.insert(0, self.owner.vendor_name)
        return names


class ServiceRequest(Base):
    __tablename__ = "service_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    service_id: Mapped[int] = mapped_column(ForeignKey("services.id"), nullable=False, index=True)
    # Optional target for a vendor-specific booking request. NULL keeps the existing marketplace-wide quote flow.
    vendor_id: Mapped[int | None] = mapped_column(ForeignKey("vendors.id"), nullable=True, index=True)
    organizer_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    requirements: Mapped[str | None] = mapped_column(Text, nullable=True)
    budget: Mapped[float | None] = mapped_column(Float, nullable=True)
    start_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    end_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="open", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    event: Mapped["Event"] = relationship()
    service: Mapped["Service"] = relationship()
    vendor: Mapped["Vendor | None"] = relationship()
    organizer: Mapped["User"] = relationship()
    offers: Mapped[list["VendorOffer"]] = relationship(back_populates="request", cascade="all, delete-orphan")
    booking: Mapped["Booking | None"] = relationship(back_populates="request", uselist=False)


class VendorOffer(Base):
    __tablename__ = "vendor_offers"
    __table_args__ = (
        UniqueConstraint("request_id", "vendor_id", name="uq_offer_request_vendor"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    request_id: Mapped[int] = mapped_column(ForeignKey("service_requests.id"), nullable=False, index=True)
    vendor_id: Mapped[int] = mapped_column(ForeignKey("vendors.id"), nullable=False, index=True)
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    inclusions: Mapped[str | None] = mapped_column(Text, nullable=True)
    message: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="submitted", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    request: Mapped["ServiceRequest"] = relationship(back_populates="offers")
    vendor: Mapped["Vendor"] = relationship()
    booking: Mapped["Booking | None"] = relationship(back_populates="offer", uselist=False)


class Booking(Base):
    __tablename__ = "bookings"
    # Historical bookings may repeat the same event/vendor/service combination
    # after a prior booking is cancelled or rejected. Only one active booking is
    # allowed for that combination at a time.
    __table_args__ = (
        Index(
            "uq_active_booking_event_vendor_service",
            "event_id",
            "vendor_id",
            "service_id",
            unique=True,
            sqlite_where=text("status IN ('pending_confirmation', 'booked')"),
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False)
    vendor_id: Mapped[int] = mapped_column(ForeignKey("vendors.id"), nullable=False)
    service_id: Mapped[int] = mapped_column(ForeignKey("services.id"), nullable=False)

    booking_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    request_id: Mapped[int | None] = mapped_column(ForeignKey("service_requests.id"), nullable=True, unique=True)
    offer_id: Mapped[int | None] = mapped_column(ForeignKey("vendor_offers.id"), nullable=True, unique=True)
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(30), default="booked", nullable=False)

    event: Mapped["Event"] = relationship(back_populates="bookings")
    request: Mapped["ServiceRequest | None"] = relationship(back_populates="booking")
    offer: Mapped["VendorOffer | None"] = relationship(back_populates="booking")
    vendor: Mapped["Vendor"] = relationship(back_populates="bookings")
    service: Mapped["Service"] = relationship(back_populates="bookings")
    review: Mapped["Review | None"] = relationship(
        back_populates="booking",
        uselist=False,
        cascade="all, delete-orphan",
    )


class Review(Base):
    # Reviews are tied to actual bookings so vendor history reflects real campus usage.
    __tablename__ = "reviews"
    __table_args__ = (
        UniqueConstraint("booking_id", name="uq_review_booking"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    booking_id: Mapped[int] = mapped_column(ForeignKey("bookings.id"), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)

    rating: Mapped[int] = mapped_column(Integer, nullable=False)
    quality_rating: Mapped[int | None] = mapped_column(Integer, nullable=True)
    reliability_rating: Mapped[int | None] = mapped_column(Integer, nullable=True)
    value_rating: Mapped[int | None] = mapped_column(Integer, nullable=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    review_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    booking: Mapped["Booking"] = relationship(back_populates="review")
    user: Mapped["User"] = relationship(back_populates="reviews")
