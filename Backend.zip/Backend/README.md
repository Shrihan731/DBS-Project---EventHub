"""Non-destructive SQLite migration for vendor onboarding, requests and offers.

Run from Backend with the same DATABASE_URL/environment as the app:
    python migrate_vendor_onboarding.py

Stop the backend before running this migration. A timestamped backup is created
before any schema changes. The migration is idempotent and never drops or
recreates existing tables or records.
"""
from datetime import datetime
from pathlib import Path
import os
import shutil
import sqlite3

from dotenv import load_dotenv
from sqlalchemy.engine import make_url

load_dotenv()
url = make_url(os.getenv("DATABASE_URL", "sqlite:///./eventhub.db"))
if url.get_backend_name() != "sqlite" or not url.database:
    raise SystemExit("This migration script supports the configured SQLite database only.")

db_path = Path(url.database)
if not db_path.is_absolute():
    db_path = (Path.cwd() / db_path).resolve()
if not db_path.exists():
    raise SystemExit(f"Database not found at {db_path}; refusing to create a new database.")

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup = db_path.with_name(f"{db_path.name}.pre_vendor_onboarding_{stamp}.bak")
shutil.copy2(db_path, backup)
print(f"Backup created: {backup}")

conn = sqlite3.connect(str(db_path))
try:
    conn.execute("PRAGMA foreign_keys=ON")
    with conn:
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"users", "vendors", "services"}.issubset(tables):
            raise RuntimeError("Expected users, vendors and services tables were not found.")

        vendor_cols = {r[1] for r in conn.execute("PRAGMA table_info(vendors)")}
        additions = [
            ("user_id", "INTEGER REFERENCES users(id)"),
            ("approval_status", "VARCHAR(20) NOT NULL DEFAULT 'pending'"),
            ("rejection_reason", "TEXT"),
            ("reviewed_by", "INTEGER REFERENCES users(id)"),
            ("reviewed_at", "DATETIME"),
            ("created_at", "DATETIME"),
        ]
        for name, declaration in additions:
            if name not in vendor_cols:
                conn.execute(f"ALTER TABLE vendors ADD COLUMN {name} {declaration}")
        conn.execute(
            "UPDATE vendors SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL"
        )
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_vendors_user_id "
            "ON vendors(user_id) WHERE user_id IS NOT NULL"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_vendors_approval_status "
            "ON vendors(approval_status)"
        )

        service_cols = {r[1] for r in conn.execute("PRAGMA table_info(services)")}
        if "vendor_owner_id" not in service_cols:
            conn.execute(
                "ALTER TABLE services ADD COLUMN vendor_owner_id INTEGER REFERENCES vendors(id)"
            )
        if "is_active" not in service_cols:
            conn.execute(
                "ALTER TABLE services ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1"
            )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_services_vendor_owner_id ON services(vendor_owner_id)"
        )

        conn.execute("""
            CREATE TABLE IF NOT EXISTS service_requests (
                id INTEGER PRIMARY KEY,
                event_id INTEGER NOT NULL REFERENCES events(id),
                service_id INTEGER NOT NULL REFERENCES services(id),
                organizer_id INTEGER NOT NULL REFERENCES users(id),
                requirements TEXT,
                budget FLOAT,
                start_at DATETIME,
                end_at DATETIME,
                status VARCHAR(30) NOT NULL DEFAULT 'open',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS ix_service_requests_event_id ON service_requests(event_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_service_requests_service_id ON service_requests(service_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_service_requests_organizer_id ON service_requests(organizer_id)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS vendor_offers (
                id INTEGER PRIMARY KEY,
                request_id INTEGER NOT NULL REFERENCES service_requests(id),
                vendor_id INTEGER NOT NULL REFERENCES vendors(id),
                amount FLOAT NOT NULL,
                inclusions TEXT,
                message TEXT,
                status VARCHAR(30) NOT NULL DEFAULT 'submitted',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT uq_offer_request_vendor UNIQUE(request_id, vendor_id)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS ix_vendor_offers_request_id ON vendor_offers(request_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS ix_vendor_offers_vendor_id ON vendor_offers(vendor_id)")

        booking_cols = {r[1] for r in conn.execute("PRAGMA table_info(bookings)")}
        if "request_id" not in booking_cols:
            conn.execute("ALTER TABLE bookings ADD COLUMN request_id INTEGER REFERENCES service_requests(id)")
        if "offer_id" not in booking_cols:
            conn.execute("ALTER TABLE bookings ADD COLUMN offer_id INTEGER REFERENCES vendor_offers(id)")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_bookings_request_id ON bookings(request_id) WHERE request_id IS NOT NULL")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_bookings_offer_id ON bookings(offer_id) WHERE offer_id IS NOT NULL")
    print("Migration completed. Existing vendor profiles remain pending for explicit review.")
except Exception:
    # The SQLite transaction is rolled back; the original backup is retained.
    print("Migration failed. The backup was retained at:", backup)
    raise
finally:
    conn.close()


## Role-based redesign additions

The application now includes an incremental startup migration for account enablement, soft-deleted services, and organizer organization-affiliation requests. Before changing an existing SQLite database, startup creates a timestamped `eventhub.pre_role_redesign_YYYYMMDD_HHMMSS.bak` copy next to it. Existing rows are preserved.

- Only administrators can create/edit official organizations and approve/reject organizer affiliation requests.
- Organizer signup stores the submitted organization details as a pending request; it does not create an approved organization.
- Deleted accounts with historical references are anonymized and disabled so old JWTs are rejected while event/booking history remains.
- Service deletion is a soft delete, and inactive/deleted services are excluded from new organizer bookings.
- SQLite foreign-key enforcement is enabled for application connections.

For the regression tests, install `requirements-dev.txt` and run `python -m pytest -q` from `Backend`. The test module uses an isolated temporary database and does not operate on `eventhub.db`.

See `../IMPLEMENTATION_NOTES.md` for the current implementation summary, actual test results, and the Windows run commands.
