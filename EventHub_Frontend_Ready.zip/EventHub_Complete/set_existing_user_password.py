"""Set a password for an existing EventHub user after upgrading the backend.

Run from the project root with the virtual environment activated:
    python set_existing_user_password.py
"""
from getpass import getpass

from sqlalchemy import inspect, select, text

from app.database import Base, SessionLocal, engine
from app import models  # noqa: F401 - register ORM models
from app.models import User
from app.security import hash_password


# Create any missing tables and ensure old SQLite databases have the new column.
Base.metadata.create_all(bind=engine)
if engine.dialect.name == "sqlite":
    inspector = inspect(engine)
    if "users" in inspector.get_table_names():
        columns = {column["name"] for column in inspector.get_columns("users")}
        if "password_hash" not in columns:
            with engine.begin() as connection:
                connection.execute(text("ALTER TABLE users ADD COLUMN password_hash VARCHAR(255)"))

email = input("Existing user's email: ").strip().lower()
password = getpass("New password (minimum 8 characters): ")
if len(password) < 8:
    raise SystemExit("Password must contain at least 8 characters.")

with SessionLocal() as db:
    user = db.scalar(select(User).where(User.email.ilike(email)))
    if user is None:
        raise SystemExit("No user with that email was found. No changes were made.")
    user.password_hash = hash_password(password)
    db.commit()
    print(f"Password set for {user.email}. You can now sign in with that account.")
