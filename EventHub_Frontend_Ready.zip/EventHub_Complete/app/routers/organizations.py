from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Organization, User
from ..schemas import OrganizationCreate, OrganizationResponse, OrganizationUpdate
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/organizations", tags=["Organizations"])


@router.post("/", response_model=OrganizationResponse, status_code=status.HTTP_201_CREATED)
def create_organization(payload: OrganizationCreate, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    existing = db.scalar(select(Organization).where(Organization.name.ilike(payload.name.strip())))
    if existing:
        raise HTTPException(status_code=409, detail="Organization already exists")
    organization = Organization(**payload.model_dump())
    organization.name = organization.name.strip()
    db.add(organization)
    db.commit()
    db.refresh(organization)
    return organization


@router.get("/", response_model=list[OrganizationResponse])
def get_organizations(db: Session = Depends(get_db)):
    return db.scalars(select(Organization).order_by(Organization.name)).all()


@router.get("/{organization_id}", response_model=OrganizationResponse)
def get_organization(organization_id: int, db: Session = Depends(get_db)):
    organization = db.get(Organization, organization_id)
    if not organization:
        raise HTTPException(status_code=404, detail="Organization not found")
    return organization


@router.patch("/{organization_id}", response_model=OrganizationResponse)
def update_organization(organization_id: int, payload: OrganizationUpdate, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    organization = db.get(Organization, organization_id)
    if not organization:
        raise HTTPException(status_code=404, detail="Organization not found")
    changes = payload.model_dump(exclude_unset=True)
    if "name" in changes and changes["name"]:
        existing = db.scalar(select(Organization).where(Organization.name.ilike(changes["name"].strip()), Organization.id != organization_id))
        if existing:
            raise HTTPException(status_code=409, detail="Another organization already uses this name")
        changes["name"] = changes["name"].strip()
    for key, value in changes.items():
        setattr(organization, key, value)
    db.commit()
    db.refresh(organization)
    return organization

