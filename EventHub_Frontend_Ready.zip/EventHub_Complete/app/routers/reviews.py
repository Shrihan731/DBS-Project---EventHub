from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import Booking, Review, User
from ..schemas import ReviewCreate, ReviewResponse, ReviewUpdate
from ..security import get_current_user

router = APIRouter(prefix="/reviews", tags=["Reviews"])


@router.post("/", response_model=ReviewResponse, status_code=status.HTTP_201_CREATED)
def create_review(payload: ReviewCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    booking = db.scalar(select(Booking).options(joinedload(Booking.event)).where(Booking.id == payload.booking_id))
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    if booking.status != "completed":
        raise HTTPException(status_code=400, detail="You can review a booking only after its status is completed")
    if current_user.role != "admin" and booking.event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the organizer of this event can review this booking")
    if db.scalar(select(Review).where(Review.booking_id == payload.booking_id)):
        raise HTTPException(status_code=409, detail="This booking already has a review")
    review = Review(**payload.model_dump(), user_id=current_user.id)
    db.add(review)
    db.commit()
    db.refresh(review)
    return review


@router.get("/", response_model=list[ReviewResponse])
def get_reviews(vendor_id: int | None = None, booking_id: int | None = None, db: Session = Depends(get_db)):
    query = select(Review).join(Booking, Review.booking_id == Booking.id)
    if vendor_id is not None:
        query = query.where(Booking.vendor_id == vendor_id)
    if booking_id is not None:
        query = query.where(Review.booking_id == booking_id)
    return db.scalars(query.order_by(Review.review_date.desc())).all()


@router.get("/{review_id}", response_model=ReviewResponse)
def get_review(review_id: int, db: Session = Depends(get_db)):
    review = db.get(Review, review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    return review


@router.patch("/{review_id}", response_model=ReviewResponse)
def update_review(review_id: int, payload: ReviewUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    review = db.get(Review, review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    if current_user.role != "admin" and review.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="You can only edit your own review")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(review, key, value)
    db.commit()
    db.refresh(review)
    return review


@router.delete("/{review_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_review(review_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    review = db.get(Review, review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    if current_user.role != "admin" and review.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="You can only delete your own review")
    db.delete(review)
    db.commit()
    return None
