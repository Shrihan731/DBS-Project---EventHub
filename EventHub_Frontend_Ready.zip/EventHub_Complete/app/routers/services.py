from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Service, User
from ..schemas import ServiceCreate, ServiceResponse, ServiceUpdate
from ..security import get_current_user, require_admin

router = APIRouter(prefix="/services", tags=["Services"])


@router.post("/", response_model=ServiceResponse, status_code=status.HTTP_201_CREATED)
def create_service(payload: ServiceCreate, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    name = payload.service_name.strip()
    if db.scalar(select(Service).where(Service.service_name.ilike(name))):
        raise HTTPException(status_code=409, detail="Service already exists")
    data = payload.model_dump()
    data["service_name"] = name
    service = Service(**data)
    db.add(service)
    db.commit()
    db.refresh(service)
    return service


@router.get("/", response_model=list[ServiceResponse])
def get_services(category: str | None = None, q: str | None = None, db: Session = Depends(get_db)):
    query = select(Service)
    if category:
        query = query.where(Service.category.ilike(f"%{category.strip()}%"))
    if q:
        query = query.where(Service.service_name.ilike(f"%{q.strip()}%"))
    return db.scalars(query.order_by(Service.category, Service.service_name)).all()


@router.get("/{service_id}", response_model=ServiceResponse)
def get_service(service_id: int, db: Session = Depends(get_db)):
    service = db.get(Service, service_id)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    return service


@router.patch("/{service_id}", response_model=ServiceResponse)
def update_service(service_id: int, payload: ServiceUpdate, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    service = db.get(Service, service_id)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    changes = payload.model_dump(exclude_unset=True)
    if changes.get("service_name"):
        name = changes["service_name"].strip()
        duplicate = db.scalar(select(Service).where(Service.service_name.ilike(name), Service.id != service_id))
        if duplicate:
            raise HTTPException(status_code=409, detail="Another service already uses this name")
        changes["service_name"] = name
    for key, value in changes.items():
        setattr(service, key, value)
    db.commit()
    db.refresh(service)
    return service

