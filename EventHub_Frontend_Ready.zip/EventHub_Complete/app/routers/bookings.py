from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import Booking, Event, Service, User, Vendor
from ..schemas import BookingCreate, BookingResponse, BookingUpdate
from ..security import get_current_user

router = APIRouter(prefix="/bookings", tags=["Bookings"])


@router.post("/", response_model=BookingResponse, status_code=status.HTTP_201_CREATED)
def create_booking(payload: BookingCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    event = db.get(Event, payload.event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role != "admin" and event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the event organizer or an admin can add bookings to this event")
    vendor = db.get(Vendor, payload.vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    service = db.get(Service, payload.service_id)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    if service not in vendor.services:
        raise HTTPException(status_code=400, detail="This vendor is not registered for the selected service")
    existing = db.scalar(select(Booking).where(
        Booking.event_id == payload.event_id,
        Booking.vendor_id == payload.vendor_id,
        Booking.service_id == payload.service_id,
    ))
    if existing:
        raise HTTPException(status_code=409, detail="A booking already exists for this event/vendor/service combination")
    booking = Booking(**payload.model_dump())
    db.add(booking)
    db.commit()
    db.refresh(booking)
    return booking


@router.get("/", response_model=list[BookingResponse])
def get_bookings(event_id: int | None = None, vendor_id: int | None = None, status_filter: str | None = None, db: Session = Depends(get_db)):
    query = select(Booking)
    if event_id is not None:
        query = query.where(Booking.event_id == event_id)
    if vendor_id is not None:
        query = query.where(Booking.vendor_id == vendor_id)
    if status_filter:
        query = query.where(Booking.status == status_filter)
    return db.scalars(query.order_by(Booking.booking_date.desc())).all()


@router.get("/{booking_id}", response_model=BookingResponse)
def get_booking(booking_id: int, db: Session = Depends(get_db)):
    booking = db.get(Booking, booking_id)
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    return booking


@router.patch("/{booking_id}", response_model=BookingResponse)
def update_booking(booking_id: int, payload: BookingUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    booking = db.scalar(select(Booking).options(joinedload(Booking.event)).where(Booking.id == booking_id))
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    if current_user.role != "admin" and booking.event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the event organizer or an admin can update this booking")
    changes = payload.model_dump(exclude_unset=True)
    if booking.review is not None and changes.get("status") == "cancelled":
        raise HTTPException(status_code=409, detail="A reviewed booking cannot be cancelled; preserve the historical record")
    for key, value in changes.items():
        setattr(booking, key, value)
    db.commit()
    db.refresh(booking)
    return booking
