from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Booking, Review, Service, User, Vendor
from ..schemas import VendorComparisonItem, VendorCreate, VendorResponse, VendorServiceResponse, VendorUpdate
from ..security import get_current_user

router = APIRouter(prefix="/vendors", tags=["Vendors"])


def _vendor_comparison(vendor: Vendor, service: Service, db: Session) -> dict:
    booking_rows = db.scalars(select(Booking).where(Booking.vendor_id == vendor.id, Booking.service_id == service.id)).all()
    booking_ids = [b.id for b in booking_rows]
    average_cost = round(sum(b.amount for b in booking_rows) / len(booking_rows), 2) if booking_rows else None
    ratings = []
    if booking_ids:
        ratings = db.scalars(select(Review.rating).where(Review.booking_id.in_(booking_ids))).all()
    average_rating = round(sum(ratings) / len(ratings), 2) if ratings else None
    return {
        "vendor_id": vendor.id,
        "vendor_name": vendor.vendor_name,
        "company_name": vendor.company_name,
        "contact_number": vendor.contact_number,
        "email": vendor.email,
        "address": vendor.address,
        "service_id": service.id,
        "service_name": service.service_name,
        "booking_count": len(booking_rows),
        "average_historical_cost": average_cost,
        "average_rating": average_rating,
        "review_count": len(ratings),
    }


@router.post("/", response_model=VendorResponse, status_code=status.HTTP_201_CREATED)
def create_vendor(payload: VendorCreate, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    contact = payload.contact_number.strip()
    duplicate = db.scalar(select(Vendor).where(Vendor.contact_number == contact))
    if duplicate:
        raise HTTPException(status_code=409, detail="A vendor with this contact number already exists")
    data = payload.model_dump()
    data["contact_number"] = contact
    if data.get("vendor_name"):
        data["vendor_name"] = data["vendor_name"].strip()
    vendor = Vendor(**data)
    db.add(vendor)
    db.commit()
    db.refresh(vendor)
    return vendor


@router.get("/compare", response_model=list[VendorComparisonItem])
def compare_vendors(service_id: int, db: Session = Depends(get_db)):
    service = db.get(Service, service_id)
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    vendors = db.scalars(select(Vendor).where(Vendor.services.any(Service.id == service_id))).all()
    results = [_vendor_comparison(vendor, service, db) for vendor in vendors]
    # Put better-rated vendors first, then those with more historical usage.
    results.sort(key=lambda x: (x["average_rating"] is not None, x["average_rating"] or 0, x["booking_count"]), reverse=True)
    return results


@router.get("/search", response_model=list[VendorResponse])
def search_vendors(q: str | None = None, category: str | None = None, service_id: int | None = None, db: Session = Depends(get_db)):
    query = select(Vendor).distinct()
    if q:
        pattern = f"%{q.strip()}%"
        query = query.where((Vendor.vendor_name.ilike(pattern)) | (Vendor.company_name.ilike(pattern)))
    if service_id is not None:
        query = query.where(Vendor.services.any(Service.id == service_id))
    if category:
        query = query.where(Vendor.services.any(Service.category.ilike(f"%{category.strip()}%")))
    return db.scalars(query.order_by(Vendor.vendor_name)).all()


@router.get("/", response_model=list[VendorResponse])
def get_vendors(q: str | None = None, service_id: int | None = None, db: Session = Depends(get_db)):
    query = select(Vendor)
    if q:
        pattern = f"%{q.strip()}%"
        query = query.where((Vendor.vendor_name.ilike(pattern)) | (Vendor.company_name.ilike(pattern)))
    if service_id is not None:
        query = query.where(Vendor.services.any(Service.id == service_id))
    return db.scalars(query.order_by(Vendor.vendor_name)).all()


@router.get("/{vendor_id}", response_model=VendorResponse)
def get_vendor(vendor_id: int, db: Session = Depends(get_db)):
    vendor = db.get(Vendor, vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    return vendor


@router.patch("/{vendor_id}", response_model=VendorResponse)
def update_vendor(vendor_id: int, payload: VendorUpdate, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    vendor = db.get(Vendor, vendor_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    changes = payload.model_dump(exclude_unset=True)
    if changes.get("contact_number"):
        contact = changes["contact_number"].strip()
        duplicate = db.scalar(select(Vendor).where(Vendor.contact_number == contact, Vendor.id != vendor_id))
        if duplicate:
            raise HTTPException(status_code=409, detail="A vendor with this contact number already exists")
        changes["contact_number"] = contact
    for key, value in changes.items():
        setattr(vendor, key, value)
    db.commit()
    db.refresh(vendor)
    return vendor


@router.post("/{vendor_id}/services/{service_id}", response_model=VendorServiceResponse, status_code=status.HTTP_201_CREATED)
def assign_service_to_vendor(vendor_id: int, service_id: int, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    vendor = db.get(Vendor, vendor_id)
    service = db.get(Service, service_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    if service in vendor.services:
        raise HTTPException(status_code=409, detail="Service already assigned to vendor")
    vendor.services.append(service)
    db.commit()
    return {"vendor_id": vendor_id, "service_id": service_id}


@router.delete("/{vendor_id}/services/{service_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_service_from_vendor(vendor_id: int, service_id: int, db: Session = Depends(get_db), _user: User = Depends(get_current_user)):
    vendor = db.get(Vendor, vendor_id)
    service = db.get(Service, service_id)
    if not vendor:
        raise HTTPException(status_code=404, detail="Vendor not found")
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    if service not in vendor.services:
        raise HTTPException(status_code=404, detail="This service is not assigned to the vendor")
    vendor.services.remove(service)
    db.commit()
    return None
