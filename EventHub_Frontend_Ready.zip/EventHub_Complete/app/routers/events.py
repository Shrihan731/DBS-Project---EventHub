from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Event, Organization, User
from ..schemas import EventCreate, EventResponse, EventUpdate
from ..security import get_current_user

router = APIRouter(prefix="/events", tags=["Events"])


@router.post("/", response_model=EventResponse, status_code=status.HTTP_201_CREATED)
def create_event(payload: EventCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    organizer = db.get(User, payload.organizer_id)
    if not organizer:
        raise HTTPException(status_code=404, detail="Organizer/user not found")
    if current_user.role != "admin" and payload.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="You can only create events under your own user account")
    if not db.get(Organization, payload.organization_id):
        raise HTTPException(status_code=404, detail="Organization not found")
    event = Event(**payload.model_dump())
    db.add(event)
    db.commit()
    db.refresh(event)
    return event


@router.get("/", response_model=list[EventResponse])
def get_events(organization_id: int | None = None, event_type: str | None = None, db: Session = Depends(get_db)):
    query = select(Event)
    if organization_id is not None:
        query = query.where(Event.organization_id == organization_id)
    if event_type:
        query = query.where(Event.event_type.ilike(f"%{event_type.strip()}%"))
    return db.scalars(query.order_by(Event.event_date)).all()


@router.get("/{event_id}", response_model=EventResponse)
def get_event(event_id: int, db: Session = Depends(get_db)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event


@router.patch("/{event_id}", response_model=EventResponse)
def update_event(event_id: int, payload: EventUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role != "admin" and event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the event organizer or an admin can edit this event")
    changes = payload.model_dump(exclude_unset=True)
    if "organizer_id" in changes and changes["organizer_id"] is not None and not db.get(User, changes["organizer_id"]):
        raise HTTPException(status_code=404, detail="Organizer/user not found")
    if "organization_id" in changes and changes["organization_id"] is not None and not db.get(Organization, changes["organization_id"]):
        raise HTTPException(status_code=404, detail="Organization not found")
    if current_user.role != "admin":
        changes.pop("organizer_id", None)
    for key, value in changes.items():
        setattr(event, key, value)
    db.commit()
    db.refresh(event)
    return event


@router.delete("/{event_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_event(event_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    if current_user.role != "admin" and event.organizer_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the event organizer or an admin can delete this event")
    db.delete(event)
    db.commit()
    return None
