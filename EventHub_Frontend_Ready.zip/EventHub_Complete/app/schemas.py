from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class UserBase(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    phone: str | None = Field(default=None, max_length=20)


class UserCreate(UserBase):
    password: str = Field(min_length=8, max_length=128)


class UserResponse(UserBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    role: str


class UserUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=100)
    phone: str | None = Field(default=None, max_length=20)


class OrganizationBase(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    organization_type: str | None = Field(default=None, max_length=50)
    contact_email: EmailStr | None = None


class OrganizationCreate(OrganizationBase):
    pass


class OrganizationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=150)
    organization_type: str | None = Field(default=None, max_length=50)
    contact_email: EmailStr | None = None


class OrganizationResponse(OrganizationBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


class EventBase(BaseModel):
    event_name: str = Field(min_length=2, max_length=150)
    event_type: str = Field(min_length=2, max_length=80)
    event_date: datetime
    venue: str = Field(min_length=2, max_length=200)
    expected_attendees: int = Field(ge=1)
    description: str | None = None
    organizer_id: int
    organization_id: int


class EventCreate(EventBase):
    pass


class EventUpdate(BaseModel):
    event_name: str | None = Field(default=None, min_length=2, max_length=150)
    event_type: str | None = Field(default=None, min_length=2, max_length=80)
    event_date: datetime | None = None
    venue: str | None = Field(default=None, min_length=2, max_length=200)
    expected_attendees: int | None = Field(default=None, ge=1)
    description: str | None = None
    organizer_id: int | None = None
    organization_id: int | None = None


class EventResponse(EventBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


class VendorBase(BaseModel):
    vendor_name: str = Field(min_length=2, max_length=150)
    company_name: str | None = Field(default=None, max_length=150)
    contact_number: str = Field(min_length=10, max_length=20)
    email: EmailStr | None = None
    address: str | None = Field(default=None, max_length=250)


class VendorCreate(VendorBase):
    pass


class VendorUpdate(BaseModel):
    vendor_name: str | None = Field(default=None, min_length=2, max_length=150)
    company_name: str | None = Field(default=None, max_length=150)
    contact_number: str | None = Field(default=None, min_length=10, max_length=20)
    email: EmailStr | None = None
    address: str | None = Field(default=None, max_length=250)


class VendorResponse(VendorBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


class ServiceBase(BaseModel):
    service_name: str = Field(min_length=2, max_length=100)
    category: str = Field(min_length=2, max_length=80)
    description: str | None = None


class ServiceCreate(ServiceBase):
    pass


class ServiceUpdate(BaseModel):
    service_name: str | None = Field(default=None, min_length=2, max_length=100)
    category: str | None = Field(default=None, min_length=2, max_length=80)
    description: str | None = None


class ServiceResponse(ServiceBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


class VendorServiceResponse(BaseModel):
    vendor_id: int
    service_id: int


class BookingBase(BaseModel):
    event_id: int
    vendor_id: int
    service_id: int
    amount: float = Field(ge=0)
    status: Literal["booked", "completed", "cancelled"] = "booked"


class BookingCreate(BookingBase):
    pass


class BookingUpdate(BaseModel):
    amount: float | None = Field(default=None, ge=0)
    status: Literal["booked", "completed", "cancelled"] | None = None


class BookingResponse(BookingBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    booking_date: datetime


class ReviewBase(BaseModel):
    booking_id: int
    rating: int = Field(ge=1, le=5)
    quality_rating: int | None = Field(default=None, ge=1, le=5)
    reliability_rating: int | None = Field(default=None, ge=1, le=5)
    value_rating: int | None = Field(default=None, ge=1, le=5)
    comment: str | None = Field(default=None, max_length=1000)


class ReviewCreate(ReviewBase):
    pass


class ReviewUpdate(BaseModel):
    rating: int | None = Field(default=None, ge=1, le=5)
    quality_rating: int | None = Field(default=None, ge=1, le=5)
    reliability_rating: int | None = Field(default=None, ge=1, le=5)
    value_rating: int | None = Field(default=None, ge=1, le=5)
    comment: str | None = Field(default=None, max_length=1000)


class ReviewResponse(ReviewBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    review_date: datetime


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class VendorComparisonItem(BaseModel):
    vendor_id: int
    vendor_name: str
    company_name: str | None
    contact_number: str
    email: str | None
    address: str | None
    service_id: int
    service_name: str
    booking_count: int
    average_historical_cost: float | None
    average_rating: float | None
    review_count: int


class DashboardSummary(BaseModel):
    users: int
    organizations: int
    events: int
    vendors: int
    services: int
    bookings: int
    completed_bookings: int
    reviews: int
