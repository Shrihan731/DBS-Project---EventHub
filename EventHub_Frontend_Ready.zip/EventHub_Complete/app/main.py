import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import inspect, select, text

from .database import Base, SessionLocal, engine
from . import models  # noqa: F401 - register all ORM models before create_all
from .routers import analytics, auth, bookings, events, organizations, reviews, services, users, vendors


# Create missing tables, then make a small backward-compatible SQLite migration.
Base.metadata.create_all(bind=engine)
if engine.dialect.name == "sqlite":
    inspector = inspect(engine)
    if "users" in inspector.get_table_names():
        user_columns = {column["name"] for column in inspector.get_columns("users")}
        if "password_hash" not in user_columns:
            with engine.begin() as connection:
                connection.execute(text("ALTER TABLE users ADD COLUMN password_hash VARCHAR(255)"))

# Optional administrator promotion: register this email normally, then set ADMIN_EMAIL in .env.
admin_email = os.getenv("ADMIN_EMAIL", "").strip().lower()
if admin_email:
    with SessionLocal() as db:
        admin_user = db.scalar(select(models.User).where(models.User.email == admin_email))
        if admin_user and admin_user.role != "admin":
            admin_user.role = "admin"
            db.commit()

app = FastAPI(
    title="EventHub API",
    description=(
        "Campus Event Vendor Management System. Search and compare vendors using "
        "campus booking history, reviews, and historical costs."
    ),
    version="1.0.0",
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(organizations.router)
app.include_router(events.router)
app.include_router(vendors.router)
app.include_router(services.router)
app.include_router(bookings.router)
app.include_router(reviews.router)
app.include_router(analytics.router)

static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/", include_in_schema=False)
def root():
    return {"message": "Welcome to EventHub API", "status": "running", "docs": "/docs", "ui": "/ui"}


@app.get("/ui", include_in_schema=False)
def ui():
    return FileResponse(static_dir / "index.html")


@app.get("/health", tags=["System"])
def health_check():
    return {"status": "healthy"}
