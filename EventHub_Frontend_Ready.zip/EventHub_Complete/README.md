# EventHub — Campus Event Vendor Management System

EventHub helps campus event organizers discover vendors and compare them using historical bookings, costs, and reviews.

## Included functionality

- User registration and password-based login with signed JWT access tokens.
- Organizer/admin roles. Public registration always creates an organizer account.
- Users can view/update their own profile; user directory access is admin-only.
- Organizations: create, list, view, and update. Organization records are retained to protect event history.
- Events: create, list/filter, view, update, and delete. Non-admin users can manage only their own events.
- Vendors: create, list/search, view, and update. Duplicate contact numbers are rejected; vendor records are retained to preserve historical data.
- Services: create, list/filter, view, and update. Service records are retained as reference data.
- Vendor-service many-to-many association, including removing an association without deleting historical bookings.
- Bookings: create, list/filter, view, update status/amount. A booking must use a service offered by that vendor; duplicate event/vendor/service combinations are rejected.
- Reviews: submit after a booking is marked `completed`, list/filter, view, edit own review, and delete own review. One review per booking.
- Vendor comparison by service: historical booking count, average historical cost, average rating, and review count.
- Analytics: summary counts and popular vendors.
- Responsive EventHub frontend at `/ui` with overview analytics, vendor discovery, historical comparison, event and booking management, reviews, organizations, service/vendor catalog, profile editing, and an admin-only user directory. The frontend uses the existing FastAPI endpoints directly; no separate Node/Vite setup is required.

## Setup on Windows / VS Code

Open a terminal in the folder containing `requirements.txt`.

```powershell
python -m venv venv
venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Open:

- Frontend: http://127.0.0.1:8000/ui
- Swagger/API testing: http://127.0.0.1:8000/docs
- Health check: http://127.0.0.1:8000/health

If PowerShell says script execution is disabled when activating the venv, use the VS Code Command Prompt terminal and run `venv\Scripts\activate.bat` instead.

## Keep your existing database

**Do not delete or overwrite your current `eventhub.db` just to use this code.** This version adds a nullable `password_hash` column to the existing `users` table. At startup, a small SQLite migration adds that column if it is missing. Existing records and IDs are retained.

To use your existing data, copy the updated `app` folder and `requirements.txt` into your current project folder, keeping your existing `eventhub.db`. If you extract this ZIP into a separate new folder, it will create a separate database in that folder by default.

Existing users created before password login was added have no password hash, so they cannot sign in immediately. To preserve an existing user ID (and access that user’s existing events), run `python set_existing_user_password.py` from the project root after installing requirements; it prompts for an existing email and a new password and stores only a password hash. Alternatively, register a new account with a different email. Do not store plaintext passwords in the database.

## Authentication in Swagger

1. Use `POST /auth/register` to create an account. Password must be at least 8 characters.
2. Use `POST /auth/login`. In the form, enter your email in the **username** field and your password in the password field.
3. Copy the `access_token` from the response.
4. Click **Authorize** in Swagger and enter the token as a Bearer token (or paste the token into the value field if Swagger adds `Bearer` automatically, follow its prompt).
5. Authenticated create/update actions will then work.

Public vendor/service/event listings and review reads do not require sign-in. Write operations require a valid token. An organizer can manage their own events and their event bookings; administrators can manage across users.

## Administrator setup (optional)

To promote a specific registered account to admin:

1. Register the account using the desired email.
2. Add `ADMIN_EMAIL=that-email@example.com` to `.env`.
3. Restart Uvicorn. At startup, EventHub promotes that existing account to `admin`.

Leave `ADMIN_EMAIL` blank if you do not need an administrator. Set `SECRET_KEY` to a long, random value before deployment; do not use the example development value publicly.

## Suggested demo workflow

1. Register and sign in.
2. Create an organization.
3. Create an event with your user ID as `organizer_id` and the new organization ID.
4. Create a vendor and a service.
5. Assign the service to the vendor using `POST /vendors/{vendor_id}/services/{service_id}`.
6. Create a booking for the event/vendor/service combination.
7. Mark the booking `completed` using `PATCH /bookings/{booking_id}`.
8. Submit a review using `POST /reviews`.
9. Open `GET /vendors/compare?service_id=...` to see booking history, average cost, and rating.
10. Open `/ui` to demonstrate the full frontend: vendor discovery and comparison, events, bookings, reviews, organizations, services, profile, analytics, and the admin view when signed in as an administrator. Use `/docs` for API-level verification.

## Important design choices

- This records vendor selections and campus booking history; it does not process payments or contact vendors to place real-world orders.
- Vendor, organization, and service records are not hard-deleted because they are referenced by historical events/bookings. Use edits and vendor-service association removal instead.
- Deleting an event also deletes its associated bookings and reviews. Use this only for events that were created incorrectly or should truly be removed.
- Vendor comparison metrics are based only on data entered into EventHub. If no historical bookings or reviews exist, the API returns `null` for those averages rather than inventing a value.
